import json
import os


global Errors
Errors = 0

def get_product_name():
    for key in (config_product["product_details"]):
        product = key
    return product

def compulsory_yes_or_no(value,product):
    answer = ["yes","no" ]
    flag = False
    if value in answer:
        flag = True
    return flag


def common_block(product):
    for key,value in config_product["product_details"][product]["common"].items():
        if key == "git_repo_url":
            result = value.startswith("http://gitlab.zycus.net/gocd-pipelines/cicd")
            if not result:
                global Errors
                Errors += 1
                print("Error in git repo")
        if key in common_list:
            answ = compulsory_yes_or_no(value,product)    
            if answ is False:
                Errors += 1
                print("Error in common block")




def common_type_block(product,type):
    for key,value in config_product["product_details"][product][type]["common"].items():
        if key in common_list:    
            answ = compulsory_yes_or_no(value,product)    
            if answ is False:
                global Errors
                Errors += 1 
                print("error in  common block  of {}".format(type))



def search_gocd_script(value):
    Flag = False
    dict = { "repo_name": "terraform_files", "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",  "branch" : "dev", "destination" : "terraform_files" }
    for each in value:
        if each == dict:
            Flag = True
    return Flag    
            
        
            
def build_block(product,type):
    for key,value in config_product["product_details"][product][type]["build"].items():
        if key == "build_repos":
            Flag = search_gocd_script(value)
            if not Flag:
                global Errors
                Errors += 1
                print("gocd Script not present in {}".format(type))
        elif key == "build_agent":
            result = value.startswith("EA")
            if not result:
                Errors += 1
                print("EA not present in  {}".format(type))

            
def deploy_downtime_block(product,type):
    for env,pair in config_product["product_details"][product][type]["deploy_downtime"].items():
        if pair["nfs_required"] == pair["copy_logs_required"]:
            print("same")
        else:
            global Errors
            Errors += 1
            print("error of  nfs in {} in {}".format(env,type))
        if pair["opcache_clear_required"]:
            ans = compulsory_yes_or_no(pair["opcache_clear_required"],product)
            if ans is True:
                if pair["opcache_clear_required"] == "yes" and len(pair["opcache_username"]) != 0 and len(pair["opcache_password"]) != 0 and len(pair["opcache_node_type"]) != 0:
                    lent = 0
                elif pair["opcache_clear_required"] == "no" and len(pair["opcache_username"]) == 0 and len(pair["opcache_password"]) == 0 and len(pair["opcache_node_type"]) == 0 :
                    lent = 0
                else:
                    Errors += 1
                    print("error of opcache  in {} in {}".format(env,type))
        

def deploy_ert_block(product,type):
    for key,value in config_product["product_details"][product][type]["deploy_ert"].items():
        if len(value["nomad_service"]) == 0:
            global Errors
            Errors += 1
            print("error of ert in {} in {}".format(key,type))
        
                
if __name__ == "__main__":
    cur_path = os.getcwd()
    file_config = os.path.join(cur_path,"sample_pipeline_config.json")
    with open(file_config) as f:
        config_product = json.loads(f.read())
    product = get_product_name()
    types = ["release","patch"]
    common_list = ["auto_deploy","test_pipeline_required","coverage_pipeline_required"]
    common_block(product)
    for type in types:
        common_type_block(product,type)
        build_block(product,type)
        deploy_downtime_block(product,type)
        deploy_ert_block(product,type)
    print(Errors)
    

        



        
