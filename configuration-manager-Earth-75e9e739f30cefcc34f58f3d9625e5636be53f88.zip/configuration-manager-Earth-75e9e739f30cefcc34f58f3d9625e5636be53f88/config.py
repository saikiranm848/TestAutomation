env_details = {
    "QC" : {
        "env_type": "lower",
        "setup_env": "QCVMWARE",
        "jira_controlled": "no",
        "nomad_regions" : "global",
        "validate_agent" : "target",
        "deploy_agent" : "target",
        "snoozing_enabled" : "no",
        "flyway_baseline" : "common"
    },
    "QM" : {
        "env_type": "lower",
        "setup_env": "QCNEW",
        "jira_controlled": "no",
        "nomad_regions" : "global",
        "validate_agent" : "target",
        "deploy_agent" : "target",
        "snoozing_enabled" : "no",
        "flyway_baseline" : "common"
    },
    "RM" : {
        "env_type": "higher",
        "setup_env": "RMPARTNER",
        "jira_controlled": "yes",
        "nomad_regions" : "global",
        "validate_agent" : "target",
        "deploy_agent" : "target",
        "snoozing_enabled" : "no",
        "flyway_baseline" : "common"
    },
    "PT" : {
        "env_type": "higher",
        "setup_env": "PARTNER",
        "jira_controlled": "yes",
        "nomad_regions" : "PT",
        "validate_agent" : "local",
        "deploy_agent" : "target",
        "snoozing_enabled" : "no",
        "flyway_baseline" : "common"
    },
    "ST" : {
        "env_type": "higher",
        "setup_env": "AUSUAT",
        "jira_controlled": "yes",
        "nomad_regions" : "ST",
        "validate_agent" : "ECS",
        "deploy_agent" : "ECS",
        "snoozing_enabled" : "yes",
        "flyway_baseline" : "common"
    },
    "STUS" : {
        "env_type": "higher",
        "setup_env": "STAGINGVMWARE",
        "jira_controlled": "yes",
        "nomad_regions" : "STUS",
        "validate_agent" : "local",
        "deploy_agent" : "target",
        "snoozing_enabled" : "yes",
        "flyway_baseline" : "common"
    },
    "MST" : {
        "env_type": "higher",
        "setup_env": "MUMSTAG",
        "jira_controlled": "yes",
        "nomad_regions" : "global",
        "validate_agent" : "target",
        "deploy_agent" : "target",
        "snoozing_enabled" : "no",
        "flyway_baseline" : "NA"
    },
    "PRAU" : {
        "env_type": "higher",
        "setup_env": "AUSPROD",
        "jira_controlled": "yes",
        "nomad_regions" : "PRAU",
        "validate_agent" : "ECS",
        "deploy_agent" : "ECS",
        "snoozing_enabled" : "yes",
        "flyway_baseline" : "common"
    },
    "PRSG" : {
        "env_type": "higher",
        "setup_env": "AWSSINGAPORE",
        "jira_controlled": "yes",
        "nomad_regions" : "PRSG",
        "validate_agent" : "ECS",
        "deploy_agent" : "ECS",
        "snoozing_enabled" : "yes",
        "flyway_baseline" : "common"
    },
    "PRUK" : {
        "env_type": "higher",
        "setup_env": "AWSPROD",
        "jira_controlled": "yes",
        "nomad_regions" : "PRUK",
        "validate_agent" : "ECS",
        "deploy_agent" : "ECS",
        "snoozing_enabled" : "yes",
        "flyway_baseline" : "common"
    },
    "PRUS" : {
        "env_type": "higher",
        "setup_env": "PROD",
        "jira_controlled": "yes",
        "nomad_regions" : "PRUS",
        "validate_agent" : "local",
        "deploy_agent" : "target",
        "snoozing_enabled" : "yes",
        "flyway_baseline" : "common"
    },
    "MPR" : {
        "env_type": "higher",
        "setup_env": "MUMPROD",
        "jira_controlled": "yes",
        "nomad_regions" : "global",
        "validate_agent" : "target",
        "deploy_agent" : "target",
        "snoozing_enabled" : "no",
        "flyway_baseline" : "NA"
    }
}

vsm_details = {
    "Release" : "",
    "Patch" : ""
}

product_details = {
    "java-maven-app" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/java-maven-app.git",
        "build_repos" : [
            {
                "repo_name": "java-maven-app-ci",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/java-maven-app-ci.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "java-maven-app",
                "repo_url": "http://gitlab.zycus.net/devops-test-applications/java-app.git",
                "branch" : "dev",
                "destination" : "java-maven-app-source"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "auto_deploy" : "yes",
        "build_tool": "maven",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "lmt_product_name" : "",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required": "no",
        "static_content_rsync_required": "no",
        "test_pipeline_required": "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-Common" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/dewdrops-common.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "ui-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/ui-dewdrops.git",
                "branch" : "master",
                "destination" : "dewdropsui"
            },
            {
                "repo_name": "dewdrops-home-bff",
                "repo_url": "git@bitbucket.org:procurement_zycus/dewdrops-home-bff.git",
                "branch" : "master",
                "destination" : "dewdropsbff"
            },
            {
                "repo_name": "common-dewdrops-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/common-dewdrops-release.git",
                "branch" : "release/earth",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "Language Management Tool",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "npm",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "yes",
        "test_pipeline_required" : "yes",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-Common-Services" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/dewdrops-common-services.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "dewdrops-common-services-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/dewdrops-common-services-release.git",
                "branch" : "release/earth",
                "destination" : "release"
            },
            {
                "repo_name": "dewdrops-common-services",
                "repo_url": "git@bitbucket.org:procurement_zycus/dewdrops-common-services.git",
                "branch" : "release/earth",
                "destination" : "services"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "npm-service",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "yes",
        "test_pipeline_required" : "yes",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-CNS" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/dewdrops-cns.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "cns-ui-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/cns-ui-dewdrops.git",
                "branch" : "master",
                "destination" : "dewdropsui"
            },
            {
                "repo_name": "dewdrops-home-bff",
                "repo_url": "git@bitbucket.org:procurement_zycus/dewdrops-home-bff.git",
                "branch" : "master",
                "destination" : "dewdropsbff"
            },
            {
                "repo_name": "dewdrops-cns-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/dewdrops-cns-release.git",
                "branch" : "release/earth",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "npm",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "yes",
        "test_pipeline_required" : "yes",
        "lmt_product_name" : "",
        "symphonycache_clear_required": "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-CNS-Services" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/dewdrops-cns-services.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "dewdrops-cns-services",
                "repo_url": "git@bitbucket.org:procurement_zycus/dewdrops-cns-services.git",
                "branch" : "master",
                "destination" : "services"
            },
            {
                "repo_name": "dewdrops-cns-services-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/dewdrops-cns-services-release.git",
                "branch" : "master",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "npm-service",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "7.9.1",
        "nomad_service" : "bff",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "yes",
        "test_pipeline_required" : "yes",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "flyway_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-LMT" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/dewdrops-lmt.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "lmt-ui-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/lmt-ui-dewdrops.git",
                "branch" : "master",
                "destination" : "dewdropsui"
            },
            {
                "repo_name": "dewdrops-home-bff",
                "repo_url": "git@bitbucket.org:procurement_zycus/dewdrops-home-bff.git",
                "branch" : "master",
                "destination" : "dewdropsbff"
            },
            {
                "repo_name": "lmt-dewdrops-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/lmt-dewdrops-release.git",
                "branch" : "master",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "npm",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "yes",
        "test_pipeline_required" : "yes",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-LMT-Services" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/dewdrops-lmt-services.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "dewdrops-lmt-services",
                "repo_url": "git@bitbucket.org:procurement_zycus/dewdrops-lmt-services.git",
                "branch" : "master",
                "destination" : "services"
            },
            {
                "repo_name": "dewdrops-lmt-services-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/dewdrops-lmt-services-release.git",
                "branch" : "master",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "npm-service",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "yes",
        "test_pipeline_required" : "yes",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-CRMS" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/dewdrops-crms.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "crms-ui-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/crms-ui-dewdrops.git",
                "branch" : "release/earth",
                "destination" : "dewdropsui"
            },
            {
                "repo_name": "crms-bff-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/crms-bff-dewdrops.git",
                "branch" : "release/earth",
                "destination" : "dewdropsbff"
            },
            {
                "repo_name": "crms-dewdrops-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/crms-dewdrops-release.git",
                "branch" : "release/earth",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "ReportStudio",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "npm",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "yes",
        "test_pipeline_required" : "yes",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-iAnalyze" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/dewdrops-ianalyze.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "ianalyze-ui-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/ianalyze-ui-dewdrops.git",
                "branch" : " releases/earth",
                "destination" : "dewdropsui"
            },
            {
                "repo_name": "ianalyze-bff-dewdrops",
                "repo_url": " git@bitbucket.org:procurement_zycus/ianalyze-bff-dewdrops.git",
                "branch" : " releases/earth",
                "destination" : "dewdropsbff"
            },
            {
                "repo_name": "ianalyze-dewdrops-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/ianalyze-dewdrops-release.git",
                "branch" : " releases/earth",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "build_tool" : "npm",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "yes",
        "test_pipeline_required" : "yes",
        "lmt_product_name" : "iAnalyze",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-iManage" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/dewdrops-imanage.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "imanage-ui-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/imanage-ui-dewdrops.git",
                "branch" : "master",
                "destination" : "dewdropsui"
            },
            {
                "repo_name": "imanage-bff-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/imanage-bff-dewdrops.git",
                "branch" : "master",
                "destination" : "dewdropsbff"
            },
            {
                "repo_name": "imanage-dewdrops-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/imanage-dewdrops-release.git",
                "branch" : "release_earth",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "build_tool" : "npm",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "yes",
        "test_pipeline_required" : "yes",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "lmt_product_name" : "iManage",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-iSave" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/dewdrops-isave.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "isave-ui-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/isave-ui-dewdrops.git",
                "branch" : "master",
                "destination" : "dewdropsui"
            },
            {
                "repo_name": "isave-bff-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/isave-bff-dewdrops.git",
                "branch" : "master",
                "destination" : "dewdropsbff"
            },
            {
                "repo_name": "isave-dewdrops-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/isave-dewdrops-release.git",
                "branch" : "gocd",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"lmt_product_name" : "iSave",
        "release_version_release" : "20.12.1.0",
        "release_version_patch" : "20.12.1.0",
        "build_tool" : "npm",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "yes",
        "test_pipeline_required" : "yes",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-iSource" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/dewdrops-isource.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "isource-ui-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/isource-ui-dewdrops.git",
                "branch" : "release/earth",
                "destination" : "dewdropsui"
            },
            {
                "repo_name": "isource-bff-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/isource-bff-dewdrops.git",
                "branch" : "release/earth",
                "destination" : "dewdropsbff"
            },
            {
                "repo_name": "isource-dewdrops-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/isource-dewdrops-release.git",
                "branch" : "release/earth",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"lmt_product_name" : "iSource",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "npm",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "yes",
        "test_pipeline_required" : "yes",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-iContract" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/dewdrops-icontract.git",
        "build_repos" : [
            {
                "repo_name": "dewdrops_common",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "icontract-dewdrops-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/icontract-dewdrops-release.git",
                "branch" : "gocd_venus",
                "destination" : "release"
            },
            {
                "repo_name": "icontract-ui-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/icontract-ui-dewdrops.git",
                "branch" : "development",
                "destination" : "dewdropsui"
            },
            {
                "repo_name": "icontract-bff-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/icontract-bff-dewdrops.git",
                "branch" : "development",
                "destination" : "dewdropsbff"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "20.12.1.0",
        "release_version_patch" : "20.12.1.0",
        "test_pipeline_required" : "no",
        "build_tool" : "npm",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "iContract-Standalone-Services" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/iContract_Standalone_Services.git",
        "build_repos" : [
            {
                "repo_name": "icontract_standalone_services",
                "repo_url": "git@bitbucket.org:procurement_zycus/icontract_standalone_services.git",
                "branch" : "master",
                "destination" : "icontract_standalone_services"
            },
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/iContract_Standalone_Services.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "20.12.1.0",
        "release_version_patch" : "20.12.1.0",
        "test_pipeline_required" : "no",
        "build_tool" : "maven",
        "build_agent" : "icontract_standalone_services",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "4.2.0",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "flyway_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-eProc" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/dewdrops-eproc.git",
        "build_repos" : [
            {
                "repo_name": "DewDrops-eProc-CI",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "DewDrops-UI",
                "repo_url": "git@bitbucket.org:procurement_zycus/dewdropsuiv3.git",
                "branch" : "master",
                "destination" : "dewdropsui"
            },
            {
                "repo_name": "eproc-bff-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/eproc-bff-dewdrops.git",
                "branch" : "master",
                "destination" : "dewdropsbff"
            },
            {
                "repo_name": "DewDrops-Release",
                "repo_url": "git@bitbucket.org:procurement_zycus/eproc-dewdrops-release.git",
                "branch" : "master",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"lmt_product_name" : "eProc",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "npm",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "yes",
        "test_pipeline_required" : "yes",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "flyway_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-eInvoice" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/dewdrops-einvoice.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "einvoice-ui-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/einvoice-ui-dewdrops.git",
                "branch" : "master",
                "destination" : "dewdropsui"
            },
            {
                "repo_name": "einvoice-bff-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/einvoice-bff-dewdrops.git",
                "branch" : "master",
                "destination" : "dewdropsbff"
            },
            {
                "repo_name": "einvoice-dewdrops-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/einvoice-dewdrops-release.git",
                "branch" : "master",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "npm",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "yes",
        "test_pipeline_required" : "yes",
		"lmt_product_name" : "eInvoice",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-iPerform" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/dewdrops-iperform.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "iperform-dewdrops-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/iperform-dewdrops-release.git",
                "branch" : "master",
                "destination" : "release"
            },
            {
                "repo_name": "iperform-ui-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/iperform-ui-dewdrops.git",
                "branch" : "master",
                "destination" : "dewdropsui"
            },
            {
                "repo_name": " iperform-bff-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/iperform-bff-dewdrops.git",
                "branch" : "master",
                "destination" : "dewdropsbff"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"lmt_product_name" : "SPM",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
		"test_pipeline_required" : "yes",
        "build_tool" : "npm",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "yes",
        "test_pipeline_required" : "yes",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "iPerform" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/iperform-classic.git",
        "build_repos" : [
            {
                "repo_name": "iperform",
                "repo_url": "git@bitbucket.org:procurement_zycus/iperform.git",
                "branch" : "release/Earth_21.02.1.0",
                "destination" : "services"
            },
			{
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/iPerform.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"lmt_product_name" : "",
        "release_version_release" : "21.02.1.0",
        "release_version_patch" : "21.02.1.0",
		"test_pipeline_required" : "no",
        "build_tool" : "maven",
        "build_agent" : "iSource_Elastic_Profile",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "7.9.1",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "yes",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "",
        "static_content_rsync_required" : "yes",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-iRequest" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/dewdrops-irequest.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "irequests2p-ui-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/irequests2p-ui-dewdrops.git",
                "branch" : "development",
                "destination" : "dewdropsui"
            },
            {
                "repo_name": "irequest-bff-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/irequest-bff-dewdrops.git",
                "branch" : "development",
                "destination" : "dewdropsbff"
            },
            {
                "repo_name": "irequest-dewdrops-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/irequest-dewdrops-release.git",
                "branch" : "development",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "npm",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "yes",
        "test_pipeline_required" : "yes",
        "lmt_product_name" : "iRequest",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-itemMaster" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/dewdrops-itemmaster.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "itemmaster-ui-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/itemmaster-ui-dewdrops.git",
                "branch" : "master",
                "destination" : "dewdropsui"
            },
            {
                "repo_name": "itemmaster-bff-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/itemmaster-bff-dewdrops.git",
                "branch" : "master",
                "destination" : "dewdropsbff"
            },
            {
                "repo_name": "dewdrops-itemmaster-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/dewdrops-itemmaster-release.git",
                "branch" : "master",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"lmt_product_name" : "eProc",
        "release_version_release" : "21.01.2.0",
        "release_version_patch" : "21.01.2.0",
        "build_tool" : "npm",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "yes",
        "test_pipeline_required" : "yes",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-iMaster" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/DewDrops-iMaster.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "imaster-ui-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/imaster-ui-dewdrops.git",
                "branch" : "release/21.01.1.0",
                "destination" : "dewdropsui"
            },
            {
                "repo_name": "imaster-bff-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/imaster-bff-dewdrops.git",
                "branch" : "release/21.01.1.0",
                "destination" : "dewdropsbff"
            },
            {
                "repo_name": "imaster-dewdrops-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/imaster-dewdrops-release.git",
                "branch" : "release/21.01.1.0",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "npm",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "yes",
        "test_pipeline_required" : "yes",
        "lmt_product_name" : "TMS",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-canvas" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/dewdrops-canvas.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "canvas-ui-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/canvas-ui-dewdrops.git",
                "branch" : "master",
                "destination" : "dewdropsui"
            },
            {
                "repo_name": "canvas-bff-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/canvas-bff-dewdrops.git",
                "branch" : "master",
                "destination" : "dewdropsbff"
            },
            {
                "repo_name": "canvas-dewdrops-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/canvas-dewdrops-release.git",
                "branch" : "master",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "build_tool" : "npm",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "yes",
        "test_pipeline_required" : "yes",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "lmt_product_name":"",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-iSupplier" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/dewdrops-isupplier.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "isupplier-ui-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/isupplier-ui-dewdrops.git",
                "branch" : "Earth_Release",
                "destination" : "dewdropsui"
            },
            {
                "repo_name": "isupplier-bff-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/isupplier-bff-dewdrops.git",
                "branch" : "Earth_Release",
                "destination" : "dewdropsbff"
            },
            {
                "repo_name": "isupplier-dewdrops-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/isupplier-dewdrops-release.git",
                "branch" : "release/earth",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "npm",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "yes",
        "test_pipeline_required" : "yes",
        "lmt_product_name" : "iSupplier",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    }, 
    "DewDrops-ZSP" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/dewdrops-zsp.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "DewDrops-UI",
                "repo_url": "git@bitbucket.org:procurement_zycus/zsp-ui-dewdrops.git",
                "branch" : "master",
                "destination" : "dewdropsui"
            },
            {
                "repo_name": "DewDrops-BFF",
                "repo_url": "git@bitbucket.org:procurement_zycus/zsp-bff-dewdrops.git",
                "branch" : "master",
                "destination" : "dewdropsbff"
            },
            {
                "repo_name": "DewDrops-Release",
                "repo_url": "git@bitbucket.org:procurement_zycus/zsp-dewdrops-release.git",
                "branch" : "master",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"lmt_product_name" : "Dewdrops",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "npm",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "yes",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "eInvoice" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/einvoice-classic.git",
        "build_repos" : [
            {
                "repo_name": "eInvoiceService",
                "repo_url": "git@bitbucket.org:procurement_zycus/einvoiceservice.git",
                "branch" : "master",
                "destination" : "eInvoiceService"
            },
            {
                "repo_name": "eInvoiceReporting",
                "repo_url": "git@bitbucket.org:procurement_zycus/einvoicereporting.git",
                "branch" : "master",
                "destination" : "eInvoiceReporting"
            },
            {
                "repo_name": "eInvoice",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/eInvoice.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "eInvoiceKnowledgeHub",
                "repo_url": "git@bitbucket.org:procurement_zycus/einvoice.git",
                "branch" : "master",
                "destination" : "eInvoiceKnowledgeHub"
            },
			{
                "repo_name": "eInvoiceUI",
                "repo_url": "git@bitbucket.org:procurement_zycus/einvoiceui.git",
                "branch" : "master",
                "destination" : "eInvoiceUI"
            },
			{
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
		"build_tool" : "maven",
        "build_agent" : "EA_Build_iRequest",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "7.9.1",
        "nomad_service" : "tomcat",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "yes",
        "opcache_username" : "einvoiceadmin",
        "opcache_password" : "einvoice123",
        "opcache_node_type" : "service_node",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "lmt_product_name" : "eInvoice",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "flyway_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "iRequestReporting" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/irequest-reporting.git",
        "build_repos" : [
            {
                "repo_name": "iRequestReporting",
                "repo_url": "git@bitbucket.org:procurement_zycus/irequest-reporting.git",
                "branch" : "gocd_dev",
                "destination" : "iRequestReporting"
            },
			{
                "repo_name": "iRequestReporting_script",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/iRequestReporting.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "maven",
        "build_agent" : "EA_Build_iRequest",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
		"lmt_product_name" : "",
        "test_pipeline_required" : "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "cwf" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/cwf-classic.git",
        "build_repos" : [
            {
                "repo_name": "CWF",
                "repo_url": "git@bitbucket.org:procurement_zycus/cwf.git",
                "branch" : "testBuild-21.01.1.0",
                "destination" : "cwf"
            },
            {
                "repo_name": "Workflow-PHP",
                "repo_url": "git@bitbucket.org:procurement_zycus/workflowphp.git",
                "branch" : "master",
                "destination" : "workflowphp"
            },
            {
                "repo_name": "Workflow-UI",
                "repo_url": "git@bitbucket.org:procurement_zycus/workflowui.git",
                "branch" : "master",
                "destination" : "workflowui"
            },
            {
                "repo_name": "CWF-CI",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/CWF.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "build_tool" : "maven",
        "build_agent" : "eProc-Job_FF_FL_Workflow_eCatalog_Itemmaster",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "7.9.1",
        "nomad_service" : "tomcat",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "yes",
        "opcache_username" : "workflowadmin",
        "opcache_password" : "workflow123",
        "opcache_node_type" : "service_node",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "lmt_product_name" : "",
        "test_pipeline_required": "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "flyway_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "FieldLibrary" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/field-library-classic.git",
        "build_repos" : [
            {
                "repo_name": "git",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/FieldLibrary.git",
                "branch" : "master",
                "destination" : "scripts"
            },
			{
                "repo_name": "fieldlibrary",
                "repo_url": "git@bitbucket.org:procurement_zycus/fieldlibrary.git",
                "branch" : "release/21.01.1.0",
                "destination" : "fieldlibrary"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "maven",
        "build_agent" : "eProc-Job_FF_FL_Workflow_eCatalog_Itemmaster",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "7.9.1",
        "nomad_service" : "tomcat",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "yes",
        "opcache_username" : "fladmin",
        "opcache_password" : "fl123",
        "opcache_node_type" : "service_node",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
		"lmt_product_name" : "",
        "test_pipeline_required": "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "flyway_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Flexiform" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/flexiform-classic.git",
        "build_repos" : [
            {
                "repo_name": "git",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/Flexiform.git",
                "branch" : "master",
                "destination" : "scripts"
            },
			{
                "repo_name": "Flexiform",
                "repo_url": "git@bitbucket.org:procurement_zycus/flexiform.git",
                "branch" : "release/21.01.1.0",
                "destination" : "flexiform"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "maven",
        "build_agent" : "eProc-Job_FF_FL_Workflow_eCatalog_Itemmaster",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "7.9.1",
        "nomad_service" : "tomcat",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "yes",
        "opcache_username" : "flexiform123",
        "opcache_password" : "yes",
        "opcache_node_type" : "service_node",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
		"lmt_product_name" : "",
        "test_pipeline_required": "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "flyway_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "iMaster-Job" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/imaster-job.git",
        "build_repos" : [
            {
                "repo_name": "iMasterApplication",
                "repo_url": "git@bitbucket.org:procurement_zycus/imasterservice.git",
                "branch" : "release-21.01.1.0",
                "destination" : "iMasterApplication"
            },
			{
                "repo_name": "iMasterClient",
                "repo_url": "git@bitbucket.org:procurement_zycus/imaster-client.git",
                "branch" : "release-21.01.1.0",
                "destination" : "iMasterClient"
            },
			{
                "repo_name": "iMasterRelease",
                "repo_url": "git@bitbucket.org:procurement_zycus/imasterrelease.git",
                "branch" : "release-21.01.1.0",
                "destination" : "release"
            },
			{
                "repo_name": "imaster",
                "repo_url": "git@bitbucket.org:procurement_zycus/imasterui.git",
                "branch" : "release-21.01.1.0",
                "destination" : "imaster"
            },
			{
                "repo_name": "iMaster-Job_CI",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/iMaster-Job.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "maven",
        "build_agent" : "iMaster_iMaster-job_Elastic_Profile",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
		"lmt_product_name" : "",
        "test_pipeline_required" : "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "iRequest" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/irequest-classic.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/iRequest.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "irequest",
                "repo_url": "git@bitbucket.org:procurement_zycus/irequest.git",
                "branch" : "development",
                "destination" : "irequest"
            },
            {
                "repo_name": "iRequestUI",
                "repo_url": "git@bitbucket.org:procurement_zycus/irequest-ui.git",
                "branch" : "development",
                "destination" : "iRequestUI"
            },
            {
                "repo_name": "iRequestReporting",
                "repo_url": "git@bitbucket.org:procurement_zycus/irequest-reporting.git",
                "branch" : "development",
                "destination" : "iRequestReporting"
            },
            {
                "repo_name": "irequest-common",
                "repo_url": "git@bitbucket.org:procurement_zycus/irequest-common.git",
                "branch" : "development",
                "destination" : "irequest-common"
            },
            {
                "repo_name": "irequestClient",
                "repo_url": "git@bitbucket.org:procurement_zycus/irequest-client.git",
                "branch" : "development",
                "destination" : "irequestClient"
            },
            {
                "repo_name": "irequest-migration",
                "repo_url": "git@bitbucket.org:procurement_zycus/irequest-migration.git",
                "branch" : "development",
                "destination" : "irequest-migration"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "maven",
        "build_agent" : "EA_Build_iRequest",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "7.9.1",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "yes",
        "opcache_clear_required" : "yes",
        "opcache_username" : "irequestadmin",
        "opcache_password" : "irequest123",
        "opcache_node_type" : "service_node",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "flyway_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "iSource-eForum" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/isource-eforum.git",
        "build_repos" : [
            {
                "repo_name": "iSource-eForum_Code_Repo",
                "repo_url": "git@bitbucket.org:procurement_zycus/isource-eforum.git",
                "branch" : "release/earth",
                "destination" : "iSource-eForum"
            },
			{
                "repo_name": "iSource-eForum_CI_Repo",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/iSource-eForum.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"test_pipeline_required" : "no",
		"lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "maven",
        "build_agent" : "iSource_Elastic_Profile",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "itemMaster" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/item-master-classic.git",
        "build_repos" : [
            {
                "repo_name": "Itemmaster_Release",
                "repo_url": " git@bitbucket.org:procurement_zycus/itemmasterrelease.git",
                "branch" : "master",
                "destination" : "release"
            },
			{
                "repo_name": "Itemmaster_UI",
                "repo_url": "git@bitbucket.org:procurement_zycus/itemmasterui.git",
                "branch" : "master",
                "destination" : "itemmasterui"
            },
			{
                "repo_name": "Itemmaster_Service",
                "repo_url": "git@bitbucket.org:procurement_zycus/itemmasterservice.git",
                "branch" : "master",
                "destination" : "itemmasterservice"
            },
			{
                "repo_name": "Itemmaster_CI",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/itemmaster.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"test_pipeline_required" : "no",
		"lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "maven",
        "build_agent" : "eProc-Job_FF_FL_Workflow_eCatalog_Itemmaster",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "7.9.1",
        "nomad_service" : "tomcat",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "yes",
        "opcache_username" : "itemmasteradmin",
        "opcache_password" : "itemmaster123",
        "opcache_node_type" : "service_node",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "flyway_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "RuleManager" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/rule-manager-classic.git",
        "build_repos" : [
            {
                "repo_name": "RuleManagerCI",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/RuleManager.git",
                "branch" : "master",
                "destination" : "scripts"
            },
			{
                "repo_name": "ruleManager",
                "repo_url": "git@bitbucket.org:procurement_zycus/rulemanager.git",
                "branch" : "release/21.01.1.0",
                "destination" : "ruleManager"
            },
			{
                "repo_name": "RuleManager-php",
                "repo_url": "git@bitbucket.org:procurement_zycus/rulemanagerphp.git",
                "branch" : "release/21.01.1.0",
                "destination" : "RuleManagerPHP"
            },
			{
                "repo_name": "RuleManagerUi",
                "repo_url": "git@bitbucket.org:procurement_zycus/rulemanagerui.git",
                "branch" : "release/21.01.1.0",
                "destination" : "RuleManagerUI"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "maven",
        "build_agent" : "RM_CWF",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "yes",
        "opcache_username" : "rmadmin",
        "opcache_password" : "rm123",
        "opcache_node_type" : "service_node",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
		"lmt_product_name" : "",
        "test_pipeline_required" : "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "TMSBulk" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/tms-bulk.git",
        "build_repos" : [
            {
                "repo_name": "TMSBulk",
                "repo_url": "git@bitbucket.org:procurement_zycus/tmsbulkservice.git",
                "branch" : "development_cicd",
                "destination" : "TMSService"
            },
            {
                "repo_name": "CI",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/TMS.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "maven",
        "build_agent" : "TMS",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "lmt_product_name" : "",
        "test_pipeline_required" : "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "TMSAudit" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/tms-audit.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/TMS.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "tmsaudittrailservice",
                "repo_url": "git@bitbucket.org:procurement_zycus/tmsaudittrailservice.git",
                "branch" : "feature/cicd",
                "destination" : "TMSService"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "maven",
        "build_agent" : "TMS",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "lmt_product_name" : "",
        "test_pipeline_required" : "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Workflow" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/workflow-classic.git",
        "build_repos" : [
            {
                "repo_name": "Workflowapp",
                "repo_url": "git@bitbucket.org:procurement_zycus/workflowapp.git",
                "branch" : "master",
                "destination" : "workflowapp"
            },
            {
                "repo_name": "WorkflowService",
                "repo_url": "git@bitbucket.org:procurement_zycus/workflow.git",
                "branch" : "master",
                "destination" : "Workflow"
            },
            {
                "repo_name": "Workflow",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/Workflow.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "build_tool" : "maven",
        "build_agent" : "FF_FL_Workflow_Elastic_Agent",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "5.2.4_1.7",
        "nomad_service" : "service",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "test_pipeline_required" : "no",
		"lmt_product_name" : "",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "eProc-Job" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/eproc-job.git",
        "build_repos" : [
            {
                "repo_name": "git",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/eProc-Job.git",
                "branch" : "master",
                "destination" : "scripts"
            },
			{
                "repo_name": "B2B-Client",
                "repo_url": "git@bitbucket.org:procurement_zycus/b2b-client.git",
                "branch" : "master",
                "destination" : "B2B-Client"
            },
			{
                "repo_name": "DynamicForm",
                "repo_url": "git@bitbucket.org:procurement_zycus/dynamicform.git",
                "branch" : "master",
                "destination" : "DynamicForm"
            },
			{
                "repo_name": "ZycusUtil-bond",
                "repo_url": "git@bitbucket.org:procurement_zycus/zycusutil-bond.git",
                "branch" : "master",
                "destination" : "ZycusUtil-bond"
            },
			{
                "repo_name": "eProcUI",
                "repo_url": "git@bitbucket.org:procurement_zycus/eprocui.git",
                "branch" : "master",
                "destination" : "eProcUI"
            },
			{
                "repo_name": "eProcJob",
                "repo_url": "git@bitbucket.org:procurement_zycus/eprocjob.git",
                "branch" : "master",
                "destination" : "eProcJob"
            },
			{
                "repo_name": "eProcReporting",
                "repo_url": "git@bitbucket.org:procurement_zycus/eprocreporting.git",
                "branch" : "master",
                "destination" : "eProcReporting"
            },
			{
                "repo_name": "eProcRelease",
                "repo_url": "git@bitbucket.org:procurement_zycus/eprocrelease.git",
                "branch" : "master",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"test_pipeline_required" : "no",
		"lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "maven",
        "build_agent" : "eProc-Job_FF_FL_Workflow_eCatalog_Itemmaster",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "eCatalog" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/ecatalog-classic.git",
        "build_repos" : [
            {
                "repo_name": "CatalogService",
                "repo_url": "git@bitbucket.org:procurement_zycus/catalogservice.git",
                "branch" : "master",
                "destination" : "catalogservice"
            },
			{
                "repo_name": "eCatalog",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/eCatalog.git",
                "branch" : "master",
                "destination" : "scripts"
            },
			{
                "repo_name": "B2B-Client",
                "repo_url": "git@bitbucket.org:procurement_zycus/b2b-client.git",
                "branch" : "B2B-Client-eCatalog-Master",
                "destination" : "B2B-Client"
            },
			{
                "repo_name": "ZycusUtil-bond",
                "repo_url": "git@bitbucket.org:procurement_zycus/zycusutil-bond.git",
                "branch" : "Zyutil-eCatalog-master",
                "destination" : "ZycusUtil-bond"
            },
			{
                "repo_name": "DynamicForm",
                "repo_url": "git@bitbucket.org:procurement_zycus/dynamicform.git",
                "branch" : "master",
                "destination" : "DynamicForm"
            },
			{
                "repo_name": "CatalogSystem",
                "repo_url": "git@bitbucket.org:procurement_zycus/catalogsystem.git",
                "branch" : "master",
                "destination" : "CatalogSystem"
            },
			{
                "repo_name": "eCatalogUI",
                "repo_url": "git@bitbucket.org:procurement_zycus/ecatalogui.git",
                "branch" : "master",
                "destination" : "eCatalogUI"
            },
			{
                "repo_name": "eCatalogRelease",
                "repo_url": "git@bitbucket.org:procurement_zycus/ecatalogrelease.git",
                "branch" : "master",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
		"test_pipeline_required" : "no",
        "build_tool" : "maven",
        "build_agent" : "eProc-Job_FF_FL_Workflow_eCatalog_Itemmaster",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "7.9.1",
        "nomad_service" : "tomcat",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "yes",
        "opcache_username" : "eprocadmin",
        "opcache_password" : "eproc123",
        "opcache_node_type" : "service_node",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "flyway_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "eProc" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/eproc-classic.git",
        "build_repos" : [
            {
                "repo_name": "B2B-Client",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/eProc.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "script",
                "repo_url": "git@bitbucket.org:procurement_zycus/b2b-client.git",
                "branch" : "master",
                "destination" : "B2B-Client"
            },
            {
                "repo_name": "DynamicForm",
                "repo_url": "git@bitbucket.org:procurement_zycus/dynamicform.git",
                "branch" : "master",
                "destination" : "DynamicForm"
            },
            {
                "repo_name": "eProcReporting",
                "repo_url": "git@bitbucket.org:procurement_zycus/eprocreporting.git",
                "branch" : "master",
                "destination" : "eProcReporting"
            },
            {
                "repo_name": "ZycusUtil-bond",
                "repo_url": "git@bitbucket.org:procurement_zycus/zycusutil-bond.git",
                "branch" : "master",
                "destination" : "ZycusUtil-bond"
            },
            {
                "repo_name": "eProcUI",
                "repo_url": "git@bitbucket.org:procurement_zycus/eprocui.git",
                "branch" : "master",
                "destination" : "eProcUI"
            },
            {
                "repo_name": "eProcRelease",
                "repo_url": "git@bitbucket.org:procurement_zycus/eprocrelease.git",
                "branch" : "master",
                "destination" : "release"
            },
            {
                "repo_name": "eProcService",
                "repo_url": "git@bitbucket.org:procurement_zycus/eprocservice.git",
                "branch" : "master",
                "destination" : "eProcService"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "build_tool" : "maven",
        "build_agent" : "eProc",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "7.9.1",
        "nomad_service" : "tomcat",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "yes",
        "opcache_username" : "eprocadmin",
        "opcache_password" : "eproc123",
        "opcache_node_type" : "service_node",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "lmt_product_name" : "",
        "test_pipeline_required" : "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "flyway_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "iMaster" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/imaster-classic.git",
        "build_repos" : [
            {
                "repo_name": "imaster",
                "repo_url": "git@bitbucket.org:procurement_zycus/imasterui.git",
                "branch" : "release-21.01.1.0",
                "destination" : "imaster"
            },
			{
                "repo_name": "iMasterClient",
                "repo_url": "git@bitbucket.org:procurement_zycus/imaster-client.git",
                "branch" : "release-21.01.1.0",
                "destination" : "iMasterClient"
            },
			{
                "repo_name": "iMasterRelease",
                "repo_url": "git@bitbucket.org:procurement_zycus/imasterrelease.git",
                "branch" : "release-21.01.1.0",
                "destination" : "release"
            },
			{
                "repo_name": "imaster_ci",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/iMaster.git",
                "branch" : "master",
                "destination" : "scripts"
            },
			{
                "repo_name": "iMasterApplication",
                "repo_url": "git@bitbucket.org:procurement_zycus/imasterservice.git",
                "branch" : "release-21.01.1.0",
                "destination" : "iMasterApplication"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "maven",
        "build_agent" : "iMaster_iMaster-job_Elastic_Profile",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "7.9.1",
        "nomad_service" : "tomcat",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "yes",
        "opcache_username" : "cmdadmin",
        "opcache_password" : "cmd123",
        "opcache_node_type" : "uiintegration_node",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
		"lmt_product_name" : "",
        "test_pipeline_required" : "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "flyway_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "P2PContractUtilization" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/P2PContractUtilization.git",
        "build_repos" : [
            {
                "repo_name": "Master",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/P2PContractUtilization.git",
                "branch" : "master",
                "destination" : "scripts"
            },
			{
                "repo_name": "P2PContractUtilization",
                "repo_url": "git@bitbucket.org:procurement_zycus/p2pcontractutilization.git",
                "branch" : "master",
                "destination" : "P2PContractUtilization"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
		"test_pipeline_required" : "no",
        "build_tool" : "maven",
        "build_agent" : "P2P_service_procurement",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "symphonycache_clear_required":"no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "service-procurement" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/service-procurement.git",
        "build_repos" : [
            {
                "repo_name": "Master",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/service-procurement.git",
                "branch" : "master",
                "destination" : "scripts"
            },
			{
                "repo_name": "service-procurement",
                "repo_url": "git@bitbucket.org:procurement_zycus/service-procurement.git",
                "branch" : "master",
                "destination" : "service-procurement"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
		"test_pipeline_required" : "no",
        "build_tool" : "maven",
        "build_agent" : "P2P_service_procurement",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "7.9.1",
        "nomad_service" : "service",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "flyway_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "zsn" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/zsn-classic.git",
        "build_repos" : [
            {
                "repo_name": "ZSNService",
                "repo_url": "git@bitbucket.org:procurement_zycus/zsnservice.git",
                "branch" : "master",
                "destination" : "ZSNService"
            },
            {
                "repo_name": "ZSN",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/ZSN.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "ZSNUI",
                "repo_url": "git@bitbucket.org:procurement_zycus/zsnui.git",
                "branch" : "master",
                "destination" : "ZSNUI"
            },
            {
                "repo_name": "ZSPService",
                "repo_url": "git@bitbucket.org:procurement_zycus/zspservice.git",
                "branch" : "master",
                "destination" : "ZSPService"
            },
            {
                "repo_name": "ZSPUI",
                "repo_url": "git@bitbucket.org:procurement_zycus/zspui.git",
                "branch" : "master",
                "destination" : "ZSPUI"
            },
            {
                "repo_name": "ZSNRelease",
                "repo_url": "git@bitbucket.org:procurement_zycus/zsnrelease.git",
                "branch" : "master",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "maven",
        "build_agent" : "ZSN",
        "package_agent" : "ZSN",
        "flyway_version" : "7.9.1",
        "nomad_service" : "tomcat",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "yes",
        "opcache_username" : "zspadmin",
        "opcache_password" : "zsp123",
        "opcache_node_type" : "service_node",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "flyway_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "iSource" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/isource-classic.git",
        "build_repos" : [
            {
                "repo_name": "iSource_Rm_Repo",
                "repo_url": "git@bitbucket.org:procurement_zycus/rmteam.git",
                "branch" : "build-deploy-CI-Green",
                "destination" : "build-deploy"
            },
			{
                "repo_name": "iSource_Code_Repo",
                "repo_url": "git@bitbucket.org:procurement_zycus/isource_repos.git",
                "branch" : "release/earth",
                "destination" : "iSource"
            },
			{
                "repo_name": "iSource_CI_Repo",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/iSource.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"test_pipeline_required" : "no",
		"lmt_product_name" : "",
        "release_version_release" : "21.12.1.0",
        "release_version_patch" : "21.12.1.0",
        "build_tool" : "maven",
        "build_agent" : "iSource_Elastic_Profile",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "upstream",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "yes",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "yes",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "iContract" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/icontract-classic.git",
        "build_repos" : [
            {
                "repo_name": "iContract_Rm_Repo",
                "repo_url": "git@bitbucket.org:procurement_zycus/rmteam.git",
                "branch" : "build-deploy-CI-Green",
                "destination" : "icontract_rm_repo"
            },
			{
                "repo_name": "icontract_repo",
                "repo_url": "git@bitbucket.org:procurement_zycus/icontract_repo.git",
                "branch" : "development",
                "destination" : "icontract_ci_repo"
            },
            {
                "repo_name": "icontract-gocd-template",
                "repo_url": "http://gitlab.zycus.net/root/icontract-gocd-template.git",
                "branch" : "Development",
                "destination" : "icontract-gocd-template"
            },
			{
                "repo_name": "iContract_CI_Repo",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/iContract.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"test_pipeline_required" : "no",
		"lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "maven",
        "build_agent" : "iContract_Elastic_Profile",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "upstream",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "yes",
        "auto_deploy" : "no",
        "symphonycache_clear_required" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "IAF" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/IAF.git",
        "build_repos" : [
            {
                "repo_name": "IAF_CI",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/IAF.git",
                "branch" : "dev",
                "destination" : "scripts"
            },
			{
                "repo_name": "IAF_SourceCode",
                "repo_url": "git@bitbucket.org:procurement_zycus/integratedautomationframework.git",
                "branch" : "IAF_CICD",
                "destination" : "integratedautomationframework"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "maven",
        "build_agent" : "IAF",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "no",
        "opcache_password" : "no",
        "opcache_node_type" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
		"lmt_product_name" : "",
		"symphonycache_clear_required" : "no",
        "test_pipeline_required": "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "iLogix-Solver" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/ilogix-solver.git",
        "build_repos" : [
            {
                "repo_name": "ilogix-java",
                "repo_url": "git@bitbucket.org:procurement_zycus/ilogix.git",
                "branch" : "release/earth",
                "destination" : "services"
            },
			{
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/iLogix-solver.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
		"test_pipeline_required" : "no",
        "build_tool" : "maven",
        "build_agent" : "iSource_Elastic_Profile",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "yes",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "sim-req-backup-service" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/sim-req-backup-service.git",
        "build_repos" : [
            {
                "repo_name": "Master",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/sim-req-backup-service.git",
                "branch" : "master",
                "destination" : "scripts"
            },
			{
                "repo_name": "sim-req-backup-service",
                "repo_url": "git@bitbucket.org:procurement_zycus/sim-req-backup-service.git",
                "branch" : "release/earth-21.01.1.0",
                "destination" : "sim-req-backup-service"
            },
            {
                "repo_name": "sim-req-backup-service-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/sim-req-backup-service-release.git",
                "branch" : "master",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "maven",
        "build_agent" : "sim-req-backup-service_elastic_profile",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "TMS-Supplier" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/tms-supplier.git",
        "build_repos" : [
            {
                "repo_name": "TMS",
                "repo_url": "git@bitbucket.org:procurement_zycus/tms.git",
                "branch" : "development",
                "destination" : "TMSService"
            },
            {
                "repo_name": "CI",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/TMS.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "maven",
        "build_agent" : "TMS",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "7.9.1",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "yes",
        "symphonycache_clear_required" : "no",
        "auto_deploy" : "no",
        "lmt_product_name" : "",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "flyway_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },   
    "iLogix-Node" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/ilogix-node.git",
        "build_repos" : [
            {
                "repo_name": "ilogix-node",
                "repo_url": "git@bitbucket.org:procurement_zycus/ilogix.git",
                "branch" : "release/earth",
                "destination" : "services"
            },
			{
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/iLogix-node.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
		"test_pipeline_required" : "yes",
        "build_tool" : "maven",
        "build_agent" : "Dewdrops_Elastic_Profile",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "yes",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "yes",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "iLogix-Java" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/ilogix-java.git",
        "build_repos" : [
            {
                "repo_name": "ilogix-java",
                "repo_url": "git@bitbucket.org:procurement_zycus/ilogix.git",
                "branch" : "release/earth",
                "destination" : "services"
            },
			{
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/iLogix-java.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
		"test_pipeline_required" : "yes",
        "build_tool" : "maven",
        "build_agent" : "iSource_Elastic_Profile",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "4.2.0",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "yes",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "yes",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "TMS-Buyer" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/TMS-Buyer.git",
        "build_repos" : [
            {
                "repo_name": "TMS",
                "repo_url": "git@bitbucket.org:procurement_zycus/tms.git",
                "branch" : "development",
                "destination" : "TMSService"
            },
            {
                "repo_name": "CI",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/TMS.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "maven",
        "build_agent" : "TMS",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "7.9.1",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "yes",
        "auto_deploy" : "no",
        "lmt_product_name" : "",
        "symphonycache_clear_required" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "flyway_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "ZDN-Command-Service" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/zdn-command-service.git",
        "build_repos" : [
            {
                "repo_name": "ZDN-Command-Service-Code",
                "repo_url": "git@bitbucket.org:procurement_zycus/zdn-command-service.git",
                "branch" : "master",
                "destination" : "services"
            },
            {
                "repo_name": "ZDN-Command-Service-CI",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/ZDN-Command-Service.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "build_tool" : "maven",
        "build_agent" : "ZDN_JAVA",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "4.2.0",
        "nomad_service" : "service",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "symphonycache_clear_required": "no",
        "auto_deploy" : "no",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "lmt_product_name" : "",
        "test_pipeline_required": "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "ZDN-Query-Service" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/ZDN-Query-Service.git",
        "build_repos" : [
            {
                "repo_name": "ZDN-Querry-Service-Code",
                "repo_url": "git@bitbucket.org:procurement_zycus/zdn-service.git",
                "branch" : "master",
                "destination" : "services"
            },
            {
                "repo_name": "ZDN-Querry-Service-CI",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/ZDN-Query-Service.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "build_tool" : "maven",
        "build_agent" : "ZDN_JAVA",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "4.2.0",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "symphonycache_clear_required": "no",
        "auto_deploy" : "no",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "lmt_product_name" : "",
        "test_pipeline_required": "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "crms-community-intelligence" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/crms-community-intelligence.git",
        "build_repos" : [
            {
                "repo_name": "crms-community-intelligence",
                "repo_url": "git@bitbucket.org:procurement_zycus/crms-community-intelligence.git",
                "branch" : "release/earth",
                "destination" : "crms-community-intelligence"
            },
			{
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/crms-community-intelligence.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
		"test_pipeline_required" : "no",
        "build_tool" : "maven",
        "build_agent" : "iSource_Elastic_Profile",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "7.9.1",
        "nomad_service" : "service",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "flyway_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-ZDN" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/DewDrops-ZDN.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "zdn-ui-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/zdn-ui-dewdrops.git",
                "branch" : "master",
                "destination" : "dewdropsui"
            },
            {
                "repo_name": "zdn-bff-dewdrops",
                "repo_url": "git@bitbucket.org:procurement_zycus/zdn-bff-dewdrops.git",
                "branch" : "master",
                "destination" : "dewdropsbff"
            },
            {
                "repo_name": "dewdrops-zdn-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/dewdrops-zdn-release.git",
                "branch" : "master",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "DewDrops",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "npm",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "symphonycache_clear_required": "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "gds-snaplogic" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/GDS-Snaplogic.git",
        "build_repos" : [
            {
                "repo_name": "Master",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/GDS-SNAPLOGIC.git",
                "branch" : "development",
                "destination" : "scripts"
            },
			{
                "repo_name": "gds-service",
                "repo_url": "git@bitbucket.org:procurement_zycus/gds-service.git",
                "branch" : "master",
                "destination" : "gds-service"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
		"test_pipeline_required" : "no",
        "build_tool" : "maven",
        "build_agent" : "eProc-Job_FF_FL_Workflow_eCatalog_Itemmaster",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "7.9.1",
        "nomad_service" : "service",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "flyway_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "iSource-WS" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/isource-ws.git",
        "build_repos" : [
            {
                "repo_name": "Master",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/iSource-WS.git",
                "branch" : "master",
                "destination" : "scripts"
            },
			{
                "repo_name": "iSource-WS",
                "repo_url": "git@bitbucket.org:procurement_zycus/gds-service.git",
                "branch" : "master",
                "destination" : "isource-ws"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
		"test_pipeline_required" : "no",
        "build_tool" : "maven",
        "build_agent" : "eProc-Job_FF_FL_Workflow_eCatalog_Itemmaster",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "iSource-Job" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/isource-job.git",
        "build_repos" : [
            {
                "repo_name": "Master",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/iSource-Job.git",
                "branch" : "master",
                "destination" : "scripts"
            },
			{
                "repo_name": "iSource-Job",
                "repo_url": "git@bitbucket.org:procurement_zycus/gds-service.git",
                "branch" : "master",
                "destination" : "isource-job"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
		"test_pipeline_required" : "no",
        "build_tool" : "maven",
        "build_agent" : "eProc-Job_FF_FL_Workflow_eCatalog_Itemmaster",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "gds-bulk" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/GDS-Bulk.git",
        "build_repos" : [
            {
                "repo_name": "Master",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/GDS-Bulk.git",
                "branch" : "development",
                "destination" : "scripts"
            },
			{
                "repo_name": "gds-service",
                "repo_url": "git@bitbucket.org:procurement_zycus/gds-service.git",
                "branch" : "master",
                "destination" : "gds-service"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
		"lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
		"test_pipeline_required" : "no",
        "build_tool" : "maven",
        "build_agent" : "eProc-Job_FF_FL_Workflow_eCatalog_Itemmaster",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "7.9.1",
        "nomad_service" : "service",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "flyway_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "ZyMail" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/zymail.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/ZyMail.git",
                "branch" : "master",
                "destination" : "CI"
            },
            {
                "repo_name": "ZyMail",
                "repo_url": "git@bitbucket.org:procurement_zycus/zymail.git",
                "branch" : "release-20.08.1.0",
                "destination" : "ZyMail"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.01.1.0",
        "build_tool" : "maven",
        "build_agent" : "icontract_standalone_services",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "7.9.1",
        "nomad_service" : "tomcat",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "yes",
        "test_pipeline_required" : "no",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "flyway_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "MRS" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/mrs.git",
        "build_repos" : [
            {
                "repo_name": "MRS",
                "repo_url": "git@bitbucket.org:procurement_zycus/mrs.git",
                "branch" : "MRS_GoCd",
                "destination" : "MRS_SVN"
            },
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/mrs.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name" : "terraform_files",
                "repo_url" : "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "78.25.63.26",
        "release_version_patch" : "78.25.63.26",
        "build_tool" : "maven",
        "build_agent" : "eProc",
        "package_agent" : "eProc",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "symphonycache_clear_required" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "MAS" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/mas.git",
        "build_repos" : [
            {
                "repo_name": "MAS",
                "repo_url": "git@bitbucket.org:procurement_zycus/mas.git",
                "branch" : "MAS_Venus_withoutGDS_GoCd",
                "destination" : "MAS_SVN"
            },
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/mas.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "78.25.63.26",
        "release_version_patch" : "78.25.63.26",
        "build_tool" : "maven",
        "build_agent" : "Merlin",
        "package_agent" : "Merlin",
        "flyway_version" : "7.9.1",
        "nomad_service" : "service",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "symphonycache_clear_required" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "flyway_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "OneView" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/oneview.git",
        "build_repos" : [
            {
                "repo_name": "oneview",
                "repo_url": "git@bitbucket.org:procurement_zycus/oneview.git",
                "branch" : "Oneview_GoCd",
                "destination" : "oneview_svn"
            },
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/OneView.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "78.25.63.28",
        "release_version_patch" : "78.25.63.28",
        "build_tool" : "maven",
        "build_agent" : "Merlin",
        "package_agent" : "Merlin",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "symphonycache_clear_required" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-Data-Extraction" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-data-extraction.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-data-extraction-release.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "scripts"
            },
            {
                "repo_name": "merlin-data-extraction",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-data-extraction.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "service"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-java",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-Data-Extraction-Service" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/Merlin-Data-Extraction-Service.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-data-extraction-service-release.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "scripts"
            },
            {
                "repo_name": "merlin-invoice-data-extraction",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-data-extraction-service.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "service"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-java",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-Invoice-PageHints" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-invoice-pagehints.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-ai-invoice-pagehints.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push": "yes",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-Invoice-BFF" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-invoice-bff.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/Merlin-Invoice-BFF.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
                "repo_name": "bff",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-invoice-bff.git",
                "branch" : "master",
                "destination" : "bff"
            },
            {
                "repo_name": "release",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-invoice-bff-release.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "release"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-bff",
        "build_agent" : "EA_Merlin_BFF",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-Invoice-Fraud-Detection" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-invoice-fraud-detection.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-invoice-fraud-detection-release.git",
                "branch" : "gocd-development",
                "destination" : "scripts"
            },
            {
                "repo_name": "merlin-invoice-data-extraction",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-invoice-fraud-detection.git",
                "branch" : "feature/MS-MER-2571",
                "destination" : "service"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-java",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-Fraud-Email-Anomaly" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-fraud-email-anomaly.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlinai-fraud-email-anomaly.git",
                "branch" : "gocd-master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push": "yes",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-Fraud-Requisition-Splitting" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-fraud-requisition-splitting.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlinai-fraud-requisition-splitting.git",
                "branch" : "gocd-development",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push": "no",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-Supplier-BFF" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/Merlin-Supplier-Risk-BFF.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/Merlin-Invoice-BFF.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
                "repo_name": "bff",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-supplier-bff.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "bff"
            },
            {
                "repo_name": "release",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-supplier-bff-release.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "release"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-bff",
        "build_agent" : "EA_Merlin_BFF",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-Spend-Risk" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-spend-risk.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin_spend_risk_bot.git",
                "branch" : "release/Mercury_20.08.1.0",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push" : "yes",
        "symphonycache_clear_required" : "no",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-Smart-Desk" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-smart-desk.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-ai-smart-desk.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push": "yes",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-Invoice-AP-Smart-Desk" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-invoice-ap-smart-desk.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-invoice-ap-smart-desk-release.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "scripts"
            },
            {
                "repo_name": "merlin-invoice-ap-smart-desk",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-invoice-ap-smart-desk.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "service"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-java",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-Invoice-Email-Crawler" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-invoice-email-crawler.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-invoice-email-crawler-release.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "scripts"
            },
            {
                "repo_name": "merlin-invoice-email-crawler",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-invoice-email-crawler.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "service"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-java",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-Supplier-Risk" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-supplier-risk.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-supplier-risk-release.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "scripts"
            },
            {
                "repo_name": "merlin-supplier-risk",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-supplier-risk.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "service"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-java",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-LibPostal" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-libpostal.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-ai-libpostal.git",
                "branch" : "gocd-development",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push" : "no",
        "symphonycache_clear_required" : "no",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-Supplier-Risk-Backend" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-supplier-risk-backend.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-supplier-risk-backend-release.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "scripts"
            },
            {
                "repo_name": "merlin-supplier-risk-backend",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-supplier-risk-backend.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "service"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-java",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-Invoice-Snab" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-invoice-snab.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-ai-invoice-snab.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push": "yes",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-Invoice-Predictions" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-invoice-predictions.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-ai-invoice-predictions.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push": "yes",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-iContract-Discovery" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/Merlin-AI-iContract-Discovery.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin_contract_discovery_ai_module.git",
                "branch" : "release/Venus_20.12.1.0",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push" : "yes",
        "symphonycache_clear_required" : "no",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-Services-BFF" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-services-bff.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/Merlin-services-BFF.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
                "repo_name": "bff",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-services-bff.git",
                "branch" : "master",
                "destination" : "bff"
            },
            {
                "repo_name": "release",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-invoice-bff-release.git",
                "branch" : "release/orange_m1_20.07.1.0",
                "destination" : "release"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-bff",
        "build_agent" : "EA_Merlin_BFF",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-eProc-BFF" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-eproc-bff.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/Merlin-Invoice-BFF.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
                "repo_name": "bff",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-eproc-bff.git",
                "branch" : "master",
                "destination" : "bff"
            },
            {
                "repo_name": "release",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-eproc-bff-release.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "release"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-bff",
        "build_agent" : "EA_Merlin_BFF",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "DewDrops-Merlin" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/dewdrops-merlin.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "dewdrops-common-services-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-dewdrops-release.git",
                "branch" : "release/earth",
                "destination" : "release"
            },
            {
                "repo_name": "dewdrops-common-services",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-dewdrops.git",
                "branch" : "release/earth",
                "destination" : "services"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "npm-service",
        "build_agent" : "EA_Build_Dewdrops",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "yes",
        "test_pipeline_required" : "yes",
        "symphonycache_clear_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-eInvoice-Cost-Allocation" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-einvoice-cost-allocation.git",
        "build_repos" : [
            {
                "repo_name": "merlin-cost-allocation-prediction-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-cost-allocation-prediction-release.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "scripts"
            },
            {
                "repo_name": "merlin-cost-allocation-prediction",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-cost-allocation-prediction.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "service"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-java",
        "build_agent" : "EA_Build_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-ZDN" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-zdn.git",
        "build_repos" : [
            {
                "repo_name": "merlin-zdn-ai-bot-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-zdn-ai-bot-release.git",
                "branch" : "release/Venus_20.12.1.0",
                "destination" : "scripts"
            },
            {
                "repo_name": "merlin-zdn-ai-bot",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-zdn-ai-bot.git",
                "branch" : "master",
                "destination" : "service"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-java",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-Eye" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-eye.git",
        "build_repos" : [
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {   
                'repo_name': 'merlin-eye',
                'repo_url': 'git@bitbucket.org:procurement_zycus/merlin-eye.git',
                'branch': 'release/Venus_21.01.1.0',
                'destination': 'scripts'
            }  
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push" : "no",
        "symphonycache_clear_required" : "no",
        "setup_execution": "yes",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-Voice" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-voice.git",
        "build_repos" : [
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
                'repo_name': 'merlin-voice',
                'repo_url': 'git@bitbucket.org:procurement_zycus/merlin-voice.git',
                'branch': 'release/Venus_21.01.1.0',
                'destination': 'scripts' 
            }  
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push" : "no",
        "symphonycache_clear_required" : "no",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-ZDN" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-zdn.git",
        "build_repos" : [
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
                'destination': 'scripts', 
                'branch': 'release/Venus_20.12.1.0', 
                'repo_url': 'git@bitbucket.org:procurement_zycus/merlin_zdn_ai_module.git', 
                'repo_name': 'merlin_zdn_ai_module'
            }  
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push" : "yes",
        "symphonycache_clear_required" : "no",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-Cost-Allocation" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-cost-allocation.git",
        "build_repos" : [
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
                'destination': 'scripts', 
                'branch': 'gocd-development', 
                'repo_url': 'git@bitbucket.org:procurement_zycus/merlin-ai-cost-allocation.git', 
                'repo_name': 'Scripts'
            }  
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push" : "yes",
        "symphonycache_clear_required" : "no",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-eProc-Autonomous-Quick-Source" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-eproc-autonomous-quick-source.git",
        "build_repos" : [
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
               "repo_name": "merlin-eproc-autonomous-quick-source-release",
               "repo_url": "git@bitbucket.org:procurement_zycus/merlin-eproc-autonomous-quick-source-release.git",
               "branch" : "release/Venus_20.12.1.0",
               "destination" : "scripts"
           },
           {
               "repo_name": "merlin-eproc-autonomous-quick-source",
               "repo_url": "git@bitbucket.org:procurement_zycus/merlin-eproc-autonomous-quick-source.git",
               "branch" : "master",
               "destination" : "service"
           }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-java",
        "build_agent" : "EA_Build_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push" : "no",
        "symphonycache_clear_required" : "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-Invoice-Suggested-Po" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-invoice-suggested-po.git",
        "build_repos" : [
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
               "repo_name": "merlin-invoice-suggested-po-release",
               "repo_url": "git@bitbucket.org:procurement_zycus/merlin-invoice-suggested-po-release.git",
               "branch" : "release/Venus_20.12.1.0",
               "destination" : "scripts"
           },
           {
               "repo_name": "merlin-invoice-suggested-po",
               "repo_url": "git@bitbucket.org:procurement_zycus/merlin-invoice-suggested-po.git",
               "branch" : "master",
               "destination" : "service"
           }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-java",
        "build_agent" : "EA_Build_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push" : "no",
        "symphonycache_clear_required" : "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-Spacy" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-spacy.git",
        "build_repos" : [
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
               "repo_name": "Scripts",
               "repo_url": "git@bitbucket.org:procurement_zycus/merlin-ai-spacy.git",
               "branch" : "release/Venus_20.12.1.0",
               "destination" : "scripts"
           }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push" : "yes",
        "symphonycache_clear_required" : "no",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-eProc-QM" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-eproc-qm.git",
        "build_repos" : [
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
                'destination': 'scripts', 
                'branch': 'release/Venus_21.01.1.0', 
                'repo_url': 'git@bitbucket.org:procurement_zycus/merlin-quote-match.git', 
                'repo_name': 'merlin-quote-match'
            }  
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push" : "yes",
        "symphonycache_clear_required" : "no",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-eProc-BA" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-eproc-ba.git",
        "build_repos" : [
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
                'destination': 'scripts', 
                'branch': 'release/Venus_21.01.1.0', 
                'repo_url': 'git@bitbucket.org:procurement_zycus/merlin-buyer-assignment.git', 
                'repo_name': 'merlin-buyer-assignment'
            }  
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push" : "yes",
        "symphonycache_clear_required" : "no",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-eProc-SD" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-eproc-sd.git",
        "build_repos" : [
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
                'destination': 'scripts', 
                'branch': 'release/Venus_21.01.1.0', 
                'repo_url': 'git@bitbucket.org:procurement_zycus/merlin-supplier-recommendation.git', 
                'repo_name': 'merlin-supplier-recommendation'
            }  
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push" : "yes",
        "symphonycache_clear_required" : "no",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-Spend-PayTerm" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-spend-payterm.git",
        "build_repos" : [
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
                'destination': 'scripts', 
                'branch': 'gocd-dev', 
                'repo_url': 'git@bitbucket.org:procurement_zycus/merlin_payment_recommender_bot.git', 
                'repo_name': 'merlin_payment_recommender_bot'
            }  
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push" : "yes",
        "symphonycache_clear_required" : "no",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-iAnalyze-PaymentTerm" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ianalyze-paymentterm.git",
        "build_repos" : [
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
               "repo_name": "merlin-payment-term-release",
               "repo_url": "git@bitbucket.org:procurement_zycus/merlin-payment-term-release.git",
               "branch" : "gocd-development",
               "destination" : "scripts"
           },
           {
               "repo_name": "merlin-payment-term",
               "repo_url": "git@bitbucket.org:procurement_zycus/merlin-payment-term.git",
               "branch" : "master",
               "destination" : "service"
           }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-java",
        "build_agent" : "EA_Build_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push" : "no",
        "symphonycache_clear_required" : "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-Spend-CategoryNormalization" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-spend-categorynormalization.git",
        "build_repos" : [
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
                'destination': 'scripts', 
                'branch': 'gocd-development', 
                'repo_url': 'git@bitbucket.org:procurement_zycus/merlin_category_normalization_bot.git', 
                'repo_name': 'merlin_category_normalization_bot'
            }  
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Build_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push" : "yes",
        "symphonycache_clear_required" : "no",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-iContract-Insta-Review" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-icontract-insta-review.git",
        "build_repos" : [
            {
                "repo_name": "merlin-icontract-insta-review-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-icontract-insta-review-release.git",
                "branch" : "release/Venus_20.12.1.0",
                "destination" : "scripts"
            },
            {
                "repo_name": "merlin-icontract-insta-review",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-icontract-insta-review.git",
                "branch" : "master",
                "destination" : "service"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-java",
        "build_agent" : "EA_Build_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-iContract-Metadata" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-icontract-metadata.git",
        "build_repos" : [
            {
                "repo_name": "merlin-icontract-metadata-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-icontract-metadata-release.git",
                "branch" : "release/Venus_20.12.1.0",
                "destination" : "scripts"
            },
            {
                "repo_name": "merlin-icontract-metadata",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-icontract-metadata.git",
                "branch" : "master",
                "destination" : "service"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-java",
        "build_agent" : "EA_Build_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-Services-BFF" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-services-bff.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/Merlin-Invoice-BFF.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
                "repo_name": "bff",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-services-bff.git",
                "branch" : "master",
                "destination" : "bff"
            },
            {
                "repo_name": "release",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-services-bff-release.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "release"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-bff",
        "build_agent" : "EA_Merlin_BFF",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-iAnalyze-BFF" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ianalyze-bff.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/Merlin-Invoice-BFF.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
                "repo_name": "bff",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-ianalyze-bff.git",
                "branch" : "master",
                "destination" : "bff"
            },
            {
                "repo_name": "release",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-ianalyze-bff-release.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "release"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-bff",
        "build_agent" : "EA_Merlin_BFF",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-Services" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-services.git",
        "build_repos" : [
            {
                "repo_name": "merlin-services-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-services-release.git",
                "branch" : "gocd-development",
                "destination" : "scripts"
            },
            {
                "repo_name": "merlin-services",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-services.git",
                "branch" : "master",
                "destination" : "service"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-java",
        "build_agent" : "EA_Build_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "MerlinUI" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/MerlinUI.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/MerlinUI.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "UI",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlinui.git",
                "branch" : "master",
                "destination" : "merlinui"
            },
            {
                "repo_name": "Release",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-ui-release.git",
                "branch" : "master",
                "destination" : "release"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-bff",
        "build_agent" : "EA_Merlin_UI",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "no",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push" : "no",
        "symphonycache_clear_required" : "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-Poller" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-poller.git",
        "build_repos" : [
            {
                "repo_name": "merlin-gds-polling-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-gds-polling-release.git",
                "branch" : "release/Venus_21.12.1.0",
                "destination" : "scripts"
            },
            {
                "repo_name": "merlin-polling",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-polling.git",
                "branch" : "release/20.09.1.0",
                "destination" : "service"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-java",
        "build_agent" : "EA_Build_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "7.9.1",
        "nomad_service" : "tomcat",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "merlin_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-iContract-BFF" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-icontract-bff.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/Merlin-Invoice-BFF.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
                "repo_name": "bff",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-icontract-bff.git",
                "branch" : "master",
                "destination" : "bff"
            },
            {
                "repo_name": "release",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-icontract-bff-release.git",
                "branch" : "release/Venus_21.01.1.0",
                "destination" : "release"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-bff",
        "build_agent" : "EA_Merlin_BFF",
        "package_agent" : "EA_Package_DewDrops",
        "flyway_version" : "",
        "nomad_service" : "bff",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-Fraud-Duplicate-Invoices" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-fraud-duplicate-invoices.git",
        "build_repos" : [
            {
                "repo_name": "merlinai-fraud-duplicate-invoices",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlinai-fraud-duplicate-invoices.git",
                "branch" : "release/Venus_20.12.1.0",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push": "yes",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "iContract-Poller" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/icontract-poller.git",
        "build_repos" : [
            {
                "repo_name": "icontract-gds-polling-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/icontract-gds-polling-release.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "icontract-polling",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin-polling.git",
                "branch" : "postgresql",
                "destination" : "service"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-java",
        "build_agent" : "EA_Build_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "7.9.1",
        "nomad_service" : "tomcat",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "merlin_common",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-Contract-Title-AI" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-contract-title-ai.git",

        "build_repos" : [
            {
                "repo_name": "merlin-contract-title-ai",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin_contract_title_ai.git",
                "branch" : "release/earth",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push": "yes",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-Expiration-Date" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-expiration-date.git",

        "build_repos" : [
            {
                "repo_name": "merlin-ai-expiration-date",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin_expiration_date_ai.git",
                "branch" : "release/earth",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push": "yes",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-Service-Dependency" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-service-dependency.git",

        "build_repos" : [
            {
                "repo_name": "merlin-ai-service-dependency",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin_service_dependency_microservice_ai.git",
                "branch" : "release/earth",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push": "yes",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-Table-Insight" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-table-insight.git",

        "build_repos" : [
            {
                "repo_name": "merlin-ai-table-insight",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin_table_insight_ai.git",
                "branch" : "release/earth",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push": "yes",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-CT-CON-FM-SUR" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-ct-con-fm-sur.git",

        "build_repos" : [
            {
                "repo_name": "merlin-ai-ct-con-fm-sur",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin_contract_term_ai.git",
                "branch" : "release/earth",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push": "yes",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-RN-RT-R" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-rn-rt-r.git",

        "build_repos" : [
            {
                "repo_name": "merlin-ai-rn-rt-r",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin_renewal_notice_ai.git",
                "branch" : "release/earth",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push": "yes",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-EXP-SOL" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-exp-sol.git",

        "build_repos" : [
            {
                "repo_name": "merlin-ai-exp-sol",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin_expiration_date_ai.git",
                "branch" : "release/earth",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push": "yes",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
      "Merlin-AI-Certinal" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-certinal.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin_certinal_ai.git",
                "branch" : "release/earth",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push": "yes",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-CUR-RT" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-cur-rt.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin_renewal_term_ai.git",
                "branch" : "release/earth",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push": "yes",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
     "Merlin-AI-JUR-CP" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-jur-cp.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin_jurisdiction_governing_law_ai.git",
                "branch" : "release/earth",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push": "yes",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-TN-IN-DR" : {
        "git_repo_url" : "http://vignesh.ks:Vicky%40123@gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-tn-in-dr.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin_indemnity_ai.git",
                "branch" : "release/earth",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push": "yes",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-Passage-Tagging-AI" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/Merlin-Passage-Tagging-AI.git",
        "build_repos" : [
            {
                "repo_name": "Scripts",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlin_passage_tagging_ai.git",
                "branch" : "release/earth",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push": "yes",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-Invoice-Integration" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-invoice-integration.git",
        "build_repos" : [
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
               "repo_name": "merlin-invoice-integration-release",
               "repo_url": "git@bitbucket.org:procurement_zycus/merlin-invoice-integration-service-release.git",
               "branch" : "feature/initial_setup",
               "destination" : "scripts"
           },
           {
               "repo_name": "merlin-invoice-integration",
               "repo_url": "git@bitbucket.org:procurement_zycus/merlin-invoice-integration-service.git",
               "branch" : "feature/initial_setup",
               "destination" : "service"
           }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-java",
        "build_agent" : "EA_Build_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "no",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push" : "no",
        "symphonycache_clear_required" : "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-eProc-Quotation-Extraction" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-eproc-quotation-extraction.git",
        "build_repos" : [
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/Merlin-Java-Common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "common",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "common"
            },
            {
               "repo_name": "merlin-supplier-quote-extraction",
               "repo_url": "git@bitbucket.org:procurement_zycus/merlin-supplier-quote-extraction.git",
               "branch" : "master",
               "destination" : "service"
           },
           {
               "repo_name": "release",
               "repo_url": "git@bitbucket.org:procurement_zycus/merlin-supplier-quote-extraction-release.git",
               "branch" : "release/GoCD_Confg",
               "destination" : "release"
           }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-java",
        "build_agent" : "EA_Merlin_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push" : "no",
        "symphonycache_clear_required" : "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-iContract-SOWMATCHING" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-icontract-sowmatching.git",
        "build_repos" : [
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
                'destination': 'scripts', 
                'branch': 'release/Venus_21.01.1.0', 
                'repo_url': 'git@bitbucket.org:procurement_zycus/sow_matching_ai_engine.git', 
                'repo_name': 'merlin-ai-icontract-sowmatching'
            }  
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push" : "yes",
        "symphonycache_clear_required" : "no",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA"
    },
    "Merlin-eProc-Buyer-Smartdesk" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-eproc-buyer-smartdesk.git",
        "build_repos" : [
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
                "repo_name": "Scripts",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/Merlin-Java-Common.git",
                "branch" : "master",
                "destination" : "scripts"
            },
            {
                "repo_name": "common",
                "repo_url": "http://gitlab.zycus.net/Zycus_CI/dewdrops_common.git",
                "branch" : "master",
                "destination" : "common"
            },
            {
               "repo_name": "merlin-supplier-quote-extraction",
               "repo_url": "git@bitbucket.org:procurement_zycus/merlin-buyer-smart-desk.git",
               "branch" : "Test_Indira",
               "destination" : "service"
           },
           {
               "repo_name": "release",
               "repo_url": "git@bitbucket.org:procurement_zycus/merlin-buyer-smart-desk-release.git",
               "branch" : "release/Venus_20.12.1.0_JDK_11",
               "destination" : "release"
           }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-java",
        "build_agent" : "EA_Build_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push" : "no",
        "symphonycache_clear_required" : "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "iContract-Merlin-Services" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/iContract-Merlin-Services.git",
        "build_repos" : [
            {
                "repo_name": "iContract-merlin-services-release",
                "repo_url": "git@bitbucket.org:procurement_zycus/iContract-merlin-services-release.git",
                "branch" : "release/mars",
                "destination" : "scripts"
            },
            {
                "repo_name": "iContract_merlin_services",
                "repo_url": "git@bitbucket.org:procurement_zycus/icontract_merlin_services.git",
                "branch" : "GDS_Sync_API",
                "destination" : "service"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-java",
        "build_agent" : "EA_Build_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "tomcat",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "centos",
        "model_push": "no",
        "setup_execution": "no",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-eProc-COA" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-eproc-coa.git",
        "build_repos" : [
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
                'destination': 'scripts', 
                'branch': 'release/Venus_21.01.1.0', 
                'repo_url': 'git@bitbucket.org:procurement_zycus/coa_prediction.git', 
                'repo_name': 'coa_prediction'
            }  
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push" : "yes",
        "symphonycache_clear_required" : "no",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA"
    },
    "iContract-Solr-Indexing" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-icontract-solr-indexing.git",
        "build_repos" : [
            {
                "repo_name": "merlinai-icontract-solr-indexing",
                "repo_url": "git@bitbucket.org:procurement_zycus/merlinai-icontract-solr-indexing.git",
                "branch" : "release/Earth",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push": "yes",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "iContract-Solr-Search" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/icontract-solr-search.git",

        "build_repos" : [
            {
                "repo_name": "icontract-solr-search",
                "repo_url": "git@bitbucket.org:procurement_zycus/icontract_solr_search.git",
                "branch" : "release/Earth",
                "destination" : "scripts"
            },
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            }
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "symphonycache_clear_required" : "no",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push": "yes",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    },
    "Merlin-AI-Translate" : {
        "git_repo_url" : "http://gitlab.zycus.net/gocd-pipelines/cicd/merlin-ai-translate.git",
        "build_repos" : [
            {
                "repo_name": "terraform_files",
                "repo_url": "http://gitlab.zycus.net/root/gocd-scripts.git",
                "branch" : "dev",
                "destination" : "terraform_files"
            },
            {
                'destination': 'scripts', 
                'branch': 'development', 
                'repo_url': 'git@bitbucket.org:procurement_zycus/merlin-ai-translate.git', 
                'repo_name': 'merlin-ai-translate'
            }  
        ],
        "lmt_product_name" : "",
        "release_version_release" : "21.01.1.0",
        "release_version_patch" : "21.03.1.0",
        "build_tool" : "merlin-ai",
        "build_agent" : "EA_Merlin_AI_Java",
        "package_agent" : "EA_Package_Legacy",
        "flyway_version" : "",
        "nomad_service" : "service",
        "nfs_required" : "yes",
        "copy_logs_required" : "no",
        "opcache_clear_required" : "no",
        "opcache_username" : "",
        "opcache_password" : "",
        "opcache_node_type" : "",
        "static_content_rsync_required" : "no",
        "auto_deploy" : "no",
        "test_pipeline_required" : "no",
        "os" : "ubuntu",
        "model_push" : "yes",
        "symphonycache_clear_required" : "no",
        "setup_execution": "yes",
        "coverage_pipeline_required" : "no",
        "flyway_type" : "NA",
        "AutoTriggerERT" : "yes",
        "AutoTriggerERTDowntime" : "no"
    }
}

coverage_details = {
    "DewDrops-LMT" : {
        "coverage" : [
            {
                "component" : "DewDrops-LMT",
                "type" : "frontend"
            },
            {
                "component" : "DewDrops-LMT-Services",
                "type" : "backend"
            }
        ],
        "automation_product_name" : "LMT",
        "automation_pipeline_name" : "LMT-local",
        "grep_expression" : "@coverageL2",
        "tenant_name" : "Eircom_QA",
        "automation_branch" : "LMT-earth",
        "automation_setup" : "QCVM"
    }
}