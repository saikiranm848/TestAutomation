from flask import Flask, render_template, request
from jinja2 import Template
import json
import config
import requests
import time
app = Flask(__name__)

@app.route("/")
def index():
    product_list = [x for x in config.pipelines]
    env_list = [x for x in config.setup_env]
    return render_template("index.html", product_list = product_list, env_list = env_list)

@app.route("/dashboard/environment/<env_name>")
def env_dashboard(env_name):
    env_list = [x for x in config.setup_env]
    product_list = [x for x in config.pipelines]
    nomad_link = "http://gitlab.zycus.net/root/gocd-scripts/raw/master/environments.json"
    nomad_data = json.loads(requests.get(nomad_link).text)
    nomad_host = nomad_data[env_name]["nomad_servers"][0]
    node_link = "http://{}:4646/v1/nodes".format(nomad_host)
    try:
        data = json.loads(requests.get(node_link, timeout=5).text)
    except:
        print("{} - unable to connect".format(node_link), flush=True)
        return render_template("environment.html",product_list = product_list, env_list = env_list, message="Unable to connect to Nomad", selected_env = env_name)

    return render_template("environment.html",product_list = product_list, env_list = env_list, node_list = data, selected_env = env_name)

@app.route("/dashboard/service/<product_name>")
def cicd_dashboard(product_name):
    product_list = [x for x in config.pipelines]
    env_list = [x for x in config.setup_env]
    # git_link = "http://gitlab.zycus.net/root/cicd-infra-json/raw/master/{}/infra.json".format(product_name)
    # product_status = requests.get(git_link).text
    # print(product_status ,flush=True)
    
    nomad_link = "http://gitlab.zycus.net/root/gocd-scripts/raw/master/environments.json"
    nomad_data = json.loads(requests.get(nomad_link).text)
    nomad_map = {}
    for key in nomad_data:
        if "nomad_servers" in nomad_data[key]:
            nomad_map[key] = nomad_data[key]["nomad_servers"]

    nomad_data_map = {}
    for key in nomad_map:
        job_link = "http://{}:4646/v1/jobs?prefix={}".format(nomad_map[key][0], product_name)
        try:
            data = json.loads(requests.get(job_link, timeout=5).text)
        except:
            print("{} - unable to connect".format(job_link), flush=True)
            continue
        for status in data:
            if status["ID"] == product_name:
                nomad_data_map[key] = status
    # print(nomad_data_map, flush=True)

    return render_template("index.html", product_list = product_list, selected_product = product_name, env_list = env_list, nomad_data = nomad_data_map)


# SERVER TIME MUST BE IST
@app.template_filter('ctime')
def timectime(s):
    return time.ctime(s)


@app.route("/cm/gocd/pipeline")
def generate_pipeline():
    return render_template("gocd-pipeline.html")

@app.route("/api/cm/gocd/pipeline/<pipeline_type>", methods=["GET"])
def generate_pipeline_api(pipeline_type):
    
    if pipeline_type == "downtime":
        env = request.values["env"]
        product = request.values["product"]
        setup_env = request.values["setup_env"]
        # stages_raw = request.values["stages"]
        stages_raw = ",".join(config.pipelines[product])
        if "apply-flyway" in stages_raw:
            flyway_version = config.flyway_versions[product]
        else:
            flyway_version = None
        stages = stages_raw.split(",")
        stages_templates = []
        compile_obj = {"env" : env, "product" :  product, "setup_env" : setup_env, "flyway_version" : flyway_version, "stages" : stages}

        for stage in stages:
            
            stages_templates.append(get_compiled_template(stage,compile_obj))

        materials = get_compiled_template("materials-{}".format(pipeline_type), compile_obj)
        head = get_compiled_template("head-{}".format(pipeline_type), compile_obj)
        
        stages = "\n".join(stages_templates)

        final = get_compiled_template("master-{}".format(pipeline_type), {"head" : head, "materials": materials, "stages": stages})

        return final

    elif pipeline_type == "ert":
        env = request.values["env"]
        product = request.values["product"]
        setup_env = request.values["setup_env"]
        compile_obj = {"env" : env, "product" :  product, "setup_env" : setup_env}
        stages_list = ["execute-ert"]
        stages_templates = []
        for stage in stages_list:
            stages_templates.append(get_compiled_template(stage,compile_obj))
        
        materials = get_compiled_template("materials-{}".format(pipeline_type), compile_obj)
        head = get_compiled_template("head-{}".format(pipeline_type), compile_obj)
        stages = "\n".join(stages_templates)
        final = get_compiled_template("master-{}".format(pipeline_type), {"head" : head, "materials": materials, "stages": stages})
        return final
    elif pipeline_type == "promote":
        to_env = request.values["to_env"]
        from_env = request.values["from_env"]
        product = request.values["product"]
        type = request.values["type"]
        compile_obj = {"env" : from_env, "product" :  product, "type": type}
        final = get_compiled_template("promote-{}-to-{}".format(type, to_env), compile_obj)
        return final



def get_compiled_template(stage, compile_obj):
    raw = Template(open('static/pipeline-j2/{}.j2'.format(stage)).read())
    return raw.render(compile_obj)



if __name__ == "__main__":
    print("SERVER TIME MUST BE IST", flush=True)
    app.run(debug=True, host="0.0.0.0", port=7080)