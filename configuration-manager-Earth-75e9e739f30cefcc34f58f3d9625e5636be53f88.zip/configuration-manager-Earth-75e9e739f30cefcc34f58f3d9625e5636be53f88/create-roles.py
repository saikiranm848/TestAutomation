import requests
from requests.auth import HTTPBasicAuth
import json
from config import approvers

API_URL = "https://10.100.0.121/go/api"
requests.packages.urllib3.disable_warnings()
#products = ["iMaster","iMaster-Job","FieldLibrary","Flexiform","RuleManager","Workflow","cwf","itemMaster","eCatalog","eInvoice","DewDrops-eInvoice","iRequest","DewDrops-iRequest","DewDrops-iContract","iSource","DewDrops-iSource","DewDrops-iManage","DewDrops-iSave","DewDrops-iAnalyze","DewDrops-CRMS","DewDrops-iPerform","DewDrops-iSupplier","sim-req-backup-service","DewDrops-CNS","DewDrops-CNS-Services","DewDrops-Common","DewDrops-Common-Services","DewDrops-LMT","DewDrops-LMT-Services","TMS-Bulk","TMSAudit","TMS","iRequestReporting","eProc","eProc-Job","DewDrops-eProc","ZyMail","zsn"]
envs = ["RM                                                                                                                            ","PT" , "ST", "STUS","PRAU", "PRUK", "PRSG", "PRUS"] 
products = ["angular-app"]
# envs = ["RM"]

ROLES = []




headers = {
    'Accept': 'application/vnd.go.cd.v3+json',
    'Content-Type': 'application/json'

}

for product in products:
    for env in envs:
        role = "Approvers_{}_{}".format(product, env)
        if product in approvers[env]:
            data = { "name" : role, 
                        "type": "gocd", 
                        "attributes" : {
                            "users": [approvers[env][product]]
                            } }
        else:
            data = { "name" : role, 
                        "type": "gocd", 
                        "attributes" : {
                            "users": [approvers[env]["default"]]
                            } }
        print("Calling API for " + str(data))
        response = requests.post('{}/admin/security/roles'.format(API_URL), auth=HTTPBasicAuth('pavan.gaikwad', 'GTD@2020'), data = json.dumps(data), headers=headers, verify=False)
        print(json.loads(response.text))