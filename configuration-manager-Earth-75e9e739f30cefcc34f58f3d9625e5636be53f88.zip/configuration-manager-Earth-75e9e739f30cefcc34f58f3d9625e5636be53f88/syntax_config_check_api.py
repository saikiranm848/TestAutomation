import requests
import sys
from pprint import pprint
import os
import argparse

#parser = argparse.ArgumentParser(description='Config name or repo id')
#parser.add_argument('product',help='Config name of product')
#args = parser.parse_args()
API_URL = "http://10.100.0.167:8153/go/api"




def syntax_config_check(config_name):
    files = []
    for f in os.listdir("."):
        if f.endswith(".gocd.yml"):
            files.append(('files[]', (f, open(f,'rb'), 'yml')))    
    username = 'JiraUser'
    password = 'Zycuspass123'
    headers = {
        'Accept': 'application/vnd.go.cd.v1+json'
    }
    res_to=requests.post(API_URL+'/admin/config_repo_ops/preflight?pluginId=yaml.config.plugin&repoId='+config_name, auth=(username,password),files=files,headers=headers)
    print(res_to.content)
    if not res_to.json()['valid']:
       sys.exit("Error found")

