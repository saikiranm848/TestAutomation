
import json
import os
import sys
import re


def search_file(file):
    kr=file.find("config_product.json")
    if kr== -1:
        print("commit not in concerned file ")
        sys.exit(1)
    

def get_number_of_pattern(file):
    x = map(int, re.findall(r'\d+', file))
    print(list(x))

if __name__ == "__main__":
    cur_path = os.getcwd()
    file_config = os.path.join(cur_path,"git_diff.txt")
    with open(file_config) as f:
        file = f.read()
    search_file(file)
    