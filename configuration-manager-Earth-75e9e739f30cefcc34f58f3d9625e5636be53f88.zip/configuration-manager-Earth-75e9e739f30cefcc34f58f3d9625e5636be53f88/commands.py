from jinja2 import Template
import json
import config
import sys
import uuid 
import os
import requests
from git.repo.base import Repo
from shutil import copy2
from ruamel.yaml import YAML

id = str(uuid.uuid4())
print("Creating ID: " + id)

def validate(product):
    #get all required details of the products
    AutoTriggerERT=config.product_details[product]['AutoTriggerERT']
    AutoTriggerERTDowntime=config.product_details[product]['AutoTriggerERTDowntime']
    copy_logs_required=config.product_details[product]['copy_logs_required']
    nfs_required=config.product_details[product]['nfs_required']

    validate_fail = ""
    #validate if AutoTriggerERT and AutoTriggerERTDowntime both are not yes
    if AutoTriggerERT=='yes' and AutoTriggerERTDowntime=='yes':
        print('AutoTriggerERT and AutoTriggerERTDowntime both cannot be yes')
        validate_fail = "yes"
        
    #validate if copy_logs_required mentioned only if nfs_required is mentioned
    if copy_logs_required=='yes':
        if nfs_required != 'yes':
            print('copy_logs_required can be used only when nfs_required is marked yes')
            validate_fail = "yes"
    #validate if opcache details are mentioned if opcache_clear_required is mentioned
    #validate if os is either of centos or ubuntu
    #validate if flyway_version is either blank or of "4.2.0, 5.2.4_1.7, 6.5.7, 7.9.1"
    if validate_fail=='yes':
        sys.exit('Validation failed. Check errors mentioned above')

def create_all_pipelines(product,env,vsm):
    print ('------------------------------------')
    print('Executing create_all_pipelines for',product)
    create_build_pipelines(product,env,vsm)
    create_package_pipelines(product,env,vsm)
    create_deploy_downtime_pipelines(product,env,vsm)
    create_deploy_ert_pipelines(product,env,vsm)
    #create_deploy_ertdowntime_pipelines(product,env,vsm)
    create_deploy_test_pipelines(product,env,vsm)
    create_coverage_pipelines(product,env,vsm)
    create_model_push_pipelines(product,vsm)

def create_deploy_pipelines(product,env,vsm):
    print ('------------------------------------')
    print('Executing create_deploy_pipelines for',product)
    create_deploy_downtime_pipelines(product,env,vsm)
    create_deploy_ert_pipelines(product,env,vsm)

def create_build_pipelines(product,env,vsm):
    
    print('Executing create_build_pipeline for',vsm)
    build_tool=config.product_details[product]['build_tool']
    stages = ["build_build_{}".format(build_tool),"build_JiraCreateTicket"]

    build_repos=config.product_details[product]['build_repos']
    build_agent=config.product_details[product]['build_agent']
    auto_deploy=config.product_details[product]['auto_deploy']
    release_version_release=config.product_details[product]['release_version_release']
    release_version_patch=config.product_details[product]['release_version_patch']
    lmt_product_name=config.product_details[product]['lmt_product_name']
    
    stages_templates = []
    compile_obj = {"product" :  product, "stages" : stages, "build_agent" : build_agent}

    for stage in stages:
        stages_templates.append(get_compiled_template(stage,compile_obj))

    compile_obj = {"product" :  product, "vsm" : vsm, "build_repos" :  build_repos, "auto_deploy" : auto_deploy, "release_version_release" : release_version_release, "release_version_patch" : release_version_patch, "lmt_product_name" : lmt_product_name}
    
    materials = get_compiled_template("build_materials", compile_obj)
    head = get_compiled_template("build_head_{}".format(build_tool), compile_obj)

    stages = "\n".join(stages_templates)
    final = get_compiled_template("build_master", {"head" : head, "materials": materials, "stages": stages})

    name = "{}_Build_{}.gocd.yml".format(product,vsm)
    save_file(name, id, final)

    return final, name

def create_package_pipelines(product,env,vsm):
    print('Executing create_package_pipelines',vsm)
    package_agent=config.product_details[product]['package_agent']
    stages = ["package_approve", "package_package", "package_JiraCreateTicket"]

    stages_templates = []
    compile_obj = {"product" :  product, "vsm" : vsm, "stages" : stages, "package_agent" : package_agent}

    for stage in stages:
        stages_templates.append(get_compiled_template(stage,compile_obj))

    materials = get_compiled_template("package_materials", compile_obj)
    head = get_compiled_template("package_head", compile_obj)

    stages = "\n".join(stages_templates)
    final = get_compiled_template("package_master", {"head" : head, "materials": materials, "stages": stages})

    name = "{}_Package_{}.gocd.yml".format(product,vsm)
    save_file(name, id, final)

    return final, name

def create_deploy_downtime_pipelines(product,env,vsm):
    if (env == "MST" or env == "MPR") and ("Merlin" not in product):
        print ('MST and MPR pipelines not required for non-Merlin')
    else:
        print('Executing create_deploy_downtime_pipelines for', env,vsm)
        stages = ["deploy_downtime_Validate","deploy_downtime_Promote","deploy_downtime_Pre_Deploy", "deploy_downtime_Deploy", "deploy_downtime_Post_Deploy"]
        
        env_type = config.env_details[env]['env_type']
        jira_controlled = config.env_details[env]['jira_controlled']
        setup_env = config.env_details[env]['setup_env']
        validate_agent = config.env_details[env]['validate_agent']
        deploy_agent = config.env_details[env]['deploy_agent']
        snoozing_enabled = config.env_details[env]['snoozing_enabled']
        flyway_baseline = config.env_details[env]['flyway_baseline']

        flyway_version=config.product_details[product]['flyway_version']
        nfs_required = config.product_details[product]['nfs_required']
        copy_logs_required = config.product_details[product]['copy_logs_required']
        opcache_clear_required = config.product_details[product]['opcache_clear_required']
        opcache_username = config.product_details[product]['opcache_username']
        opcache_password = config.product_details[product]['opcache_password']
        opcache_node_type = config.product_details[product]['opcache_node_type']
        auto_deploy = config.product_details[product]['auto_deploy']
        symphonycache_clear_required = config.product_details[product]['symphonycache_clear_required']
        flyway_type = config.product_details[product]['flyway_type']

        os=config.product_details[product]['os']
        setup_execution=config.product_details[product]['setup_execution']
        model_push=config.product_details[product]['model_push']
        static_content_rsync_required = config.product_details[product]['static_content_rsync_required']

        stages_templates = []
        compile_obj = {"env" : env, "product" :  product, "vsm" : vsm, "env_type" : env_type, "snoozing_enabled": snoozing_enabled, "validate_agent" : validate_agent, "deploy_agent" : deploy_agent, "jira_controlled" : jira_controlled, "setup_env" : setup_env, "flyway_version" : flyway_version, "nfs_required" : nfs_required, "copy_logs_required" : copy_logs_required, "opcache_clear_required" : opcache_clear_required, "static_content_rsync_required" : static_content_rsync_required, "opcache_username" : opcache_username, "opcache_password" : opcache_password, "opcache_node_type" : opcache_node_type, "auto_deploy" : auto_deploy, "stages" : stages, "symphonycache_clear_required" : symphonycache_clear_required, "os" : os, "setup_execution" : setup_execution, "model_push" : model_push, "flyway_type" : flyway_type, "flyway_baseline" : flyway_baseline}

        for stage in stages:
            stages_templates.append(get_compiled_template(stage,compile_obj))

        materials = get_compiled_template("deploy_downtime_materials", compile_obj)
        head = get_compiled_template("deploy_downtime_head", compile_obj)

        stages = "\n".join(stages_templates)
        final = get_compiled_template("deploy_downtime_master", {"head" : head, "materials": materials, "stages": stages})

        name = "{}_Deploy_{}_Downtime_{}.gocd.yml".format(product,env,vsm)
        save_file(name, id, final)

        return final, name

def create_deploy_test_pipelines(product,env,vsm):
    if env == "QC":
        print('Executing create_deploy_test_pipelines for',env,vsm)
        stages = ["test_TriggerL0","test_TriggerL1","test_TriggerL2", "test_TriggerPerformance"]
        
        env_type = config.env_details[env]['env_type']
        jira_controlled = config.env_details[env]['jira_controlled']

        build_agent=config.product_details[product]['build_agent']

        stages_templates = []
        compile_obj = {"env" : env, "product" :  product, "vsm" : vsm, "env_type" : env_type, "jira_controlled" : jira_controlled, "stages" : stages, "build_agent" : build_agent}

        for stage in stages:
            stages_templates.append(get_compiled_template(stage,compile_obj))

        materials = get_compiled_template("test_materials", compile_obj)
        head = get_compiled_template("test_head", compile_obj)

        stages = "\n".join(stages_templates)
        final = get_compiled_template("test_master", {"head" : head, "materials": materials, "stages": stages})

        name = "{}_Test_{}.gocd.yml".format(product,vsm)
        save_file(name, id, final)

        return final, name
    else:
        print('Test pipeline not required for', env)

def create_deploy_ert_pipelines(product,env,vsm):
    if (env == "MST" or env == "MPR") and ("Merlin" not in product):
        print ('MST and MPR pipelines not required for non-Merlin')
    else:
        print('Executing create_deploy_ert_pipelines for', env,vsm)
        stages = ["deploy_ert_Validate","deploy_ert_Promote","deploy_ert_Pre_Deploy", "deploy_ert_Deploy", "deploy_ert_Post_Deploy"]
        
        env_type = config.env_details[env]['env_type']
        jira_controlled = config.env_details[env]['jira_controlled']
        validate_agent = config.env_details[env]['validate_agent']
        deploy_agent = config.env_details[env]['deploy_agent']

        AutoTriggerERT = config.product_details[product]['AutoTriggerERT']
        nomad_service = config.product_details[product]['nomad_service']
        static_content_rsync_required = config.product_details[product]['static_content_rsync_required']
        symphonycache_clear_required = config.product_details[product]['symphonycache_clear_required']

        stages_templates = []
        compile_obj = {"env" : env, "product" :  product, "vsm" : vsm, "env_type" : env_type, "validate_agent" : validate_agent, "deploy_agent" : deploy_agent, "AutoTriggerERT" : AutoTriggerERT, "jira_controlled" : jira_controlled, "nomad_service" : nomad_service, "static_content_rsync_required" : static_content_rsync_required, "symphonycache_clear_required" : symphonycache_clear_required, "stages" : stages}

        for stage in stages:
            stages_templates.append(get_compiled_template(stage,compile_obj))

        materials = get_compiled_template("deploy_ert_materials", compile_obj)
        head = get_compiled_template("deploy_ert_head", compile_obj)

        stages = "\n".join(stages_templates)
        final = get_compiled_template("deploy_ert_master", {"head" : head, "materials": materials, "stages": stages})

        name = "{}_Deploy_{}_ERT_{}.gocd.yml".format(product,env,vsm)
        save_file(name, id, final)

        return final, name

def create_deploy_ertdowntime_pipelines(product,env,vsm):
    print('Executing create_deploy_ert_downtime_pipelines for', env,vsm)
    stages = ["deploy_ertdowntime_Validate","deploy_ertdowntime_Promote","deploy_ertdowntime_Pre_Deploy", "deploy_ertdowntime_Deploy", "deploy_ertdowntime_Post_Deploy"]
    
    env_type = config.env_details[env]['env_type']
    jira_controlled = config.env_details[env]['jira_controlled']
    setup_env = config.env_details[env]['setup_env']
    validate_agent = config.env_details[env]['validate_agent']
    deploy_agent = config.env_details[env]['deploy_agent']
    snoozing_enabled = config.env_details[env]['snoozing_enabled']
    flyway_baseline = config.env_details[env]['flyway_baseline']
    
    AutoTriggerERTDowntime = config.product_details[product]['AutoTriggerERTDowntime']
    flyway_version=config.product_details[product]['flyway_version']
    opcache_clear_required = config.product_details[product]['opcache_clear_required']
    opcache_username = config.product_details[product]['opcache_username']
    opcache_password = config.product_details[product]['opcache_password']
    opcache_node_type = config.product_details[product]['opcache_node_type']
    auto_deploy = config.product_details[product]['auto_deploy']
    symphonycache_clear_required = config.product_details[product]['symphonycache_clear_required']
    flyway_type = config.product_details[product]['flyway_type']
    static_content_rsync_required = config.product_details[product]['static_content_rsync_required']

    stages_templates = []
    compile_obj = {"env" : env, "product" :  product, "vsm" : vsm, "env_type" : env_type, "snoozing_enabled": snoozing_enabled, "validate_agent" : validate_agent, "deploy_agent" : deploy_agent, "AutoTriggerERTDowntime" : AutoTriggerERTDowntime, "jira_controlled" : jira_controlled, "setup_env" : setup_env, "flyway_version" : flyway_version, "opcache_clear_required" : opcache_clear_required, "static_content_rsync_required" : static_content_rsync_required, "opcache_username" : opcache_username, "opcache_password" : opcache_password, "opcache_node_type" : opcache_node_type, "auto_deploy" : auto_deploy, "stages" : stages, "symphonycache_clear_required" : symphonycache_clear_required, "flyway_type" : flyway_type, "flyway_baseline" : flyway_baseline}

    for stage in stages:
        stages_templates.append(get_compiled_template(stage,compile_obj))

    materials = get_compiled_template("deploy_ertdowntime_materials", compile_obj)
    head = get_compiled_template("deploy_ertdowntime_head", compile_obj)

    stages = "\n".join(stages_templates)
    final = get_compiled_template("deploy_ertdowntime_master", {"head" : head, "materials": materials, "stages": stages})

    name = "{}_Deploy_{}_ERTDowntime_{}.gocd.yml".format(product,env,vsm)
    save_file(name, id, final)

    return final, name

def create_model_push_pipelines(product,vsm):
    model_push_pipeline_required=config.product_details[product]['model_push']
    if model_push_pipeline_required == "yes":
        print('Executing create_model_push_pipelines for', product,vsm)
        build_agent=config.product_details[product]['build_agent']
        stages = ["model_push_Model_Push",]

        stages_templates = []
        compile_obj = {"product" :  product, "vsm" : vsm, "build_agent" : build_agent, "stages" : stages}

        for stage in stages:
            stages_templates.append(get_compiled_template(stage,compile_obj))

        materials = get_compiled_template("model_push_materials", compile_obj)
        head = get_compiled_template("model_push_head", compile_obj)

        stages = "\n".join(stages_templates)
        final = get_compiled_template("model_push_master", {"head" : head, "materials": materials, "stages": stages})

        name = "{}_Model_Push_{}.gocd.yml".format(product,vsm)
        save_file(name, id, final)

        return final, name
    else:
        print('Model Push pipeline not required for', product,vsm)
    
def create_coverage_pipelines(product,env,vsm):
    coverage_pipeline_required=config.product_details[product]['coverage_pipeline_required']
    if coverage_pipeline_required == "yes":
        print('Executing create_coverage_pipelines')
        build_tool=config.product_details[product]['build_tool']
        stages = ["coverage_Build","coverage_Deploy","coverage_Test", "coverage_Report"]

        build_repos=config.product_details[product]['build_repos']
        build_agent=config.product_details[product]['build_agent']

        product_details=config.product_details

        coverage=config.coverage_details[product]['coverage']
        automation_product_name=config.coverage_details[product]['automation_product_name']
        automation_pipeline_name=config.coverage_details[product]['automation_pipeline_name']
        grep_expression=config.coverage_details[product]['grep_expression']
        tenant_name=config.coverage_details[product]['tenant_name']
        automation_branch=config.coverage_details[product]['automation_branch']
        automation_setup=config.coverage_details[product]['automation_setup']

        stages_templates = []
        compile_obj = {"product" :  product, "product_details" : product_details, "stages" : stages, "build_repos" : build_repos, "build_agent" : build_agent, "coverage" : coverage, "automation_product_name" : automation_product_name, "automation_pipeline_name" : automation_pipeline_name, "grep_expression" : grep_expression, "tenant_name": tenant_name, "automation_branch": automation_branch, "automation_setup": automation_setup}

        for stage in stages:
            stages_templates.append(get_compiled_template(stage,compile_obj))

        materials = get_compiled_template("coverage_materials", compile_obj)
        head = get_compiled_template("coverage_head", compile_obj)

        stages = "\n".join(stages_templates)
        final = get_compiled_template("coverage_master", {"head" : head, "materials": materials, "stages": stages})

        name = "{}_Coverage.gocd.yml".format(product)
        save_file(name, id, final)

        return final, name
    else:
        print('Coverage pipeline not required for', product)

def commit_to_git(product,repo,new_branch):
    print('new_branch',new_branch)
    folder_name = repo.split("/")[-1].split(".")[0]
    Repo.clone_from(repo, "{}/{}".format(id, folder_name), branch='master')
    os.chdir("{}/{}".format(id, folder_name))
    names = os.listdir("../pipelines")
    os.system("git checkout -b {}".format(new_branch))
    os.system("git pull origin {}".format(new_branch))
    for name in names:
        srcname = os.path.join("../pipelines".format(id), name)
        dstname = os.path.join(name)
        copy2(srcname, dstname)
    os.system("git add *")
    os.system('git commit -m "bot checking in" --author="platform_devops <platform_coe@zycus.com>"')
    os.system("git push origin {}".format(new_branch))
    raise_merge_request(folder_name,new_branch)

def raise_merge_request(folder_name,new_branch):
    repo_name = folder_name
    gitlabAccessToken = 'r6YZQtTerPb37tgdUL13'
    header = {'PRIVATE-TOKEN' : gitlabAccessToken}
    project_url = 'http://gitlab.zycus.net/api/v4/projects/gocd-pipelines%2Fcicd%2F{}'.format(repo_name)
    project_details = requests.get(project_url, headers=header)
    project_details_json = project_details.json()
    project_id = project_details_json['id']
    MR_api_url = 'http://gitlab.zycus.net/api/v4/projects/{}/merge_requests'.format(project_id)

    sourceBranch = new_branch
    targetBranch = 'master'
    title = 'MR from {} to master'.format(new_branch)
    description = 'description'

    header = {'PRIVATE-TOKEN' : gitlabAccessToken}
    params = {
            'id'            : id,    
            'title'         : title, 
            'source_branch' : sourceBranch, 
            'target_branch' : targetBranch
            }

    reply = requests.post(MR_api_url, data=params, headers=header)
    status = json.loads(reply.text)
    MR_URL = status['web_url']
    print ('MR raised at: ', MR_URL)

def save_file(filename, destination_folder, filecontent):
    f = open("{}/pipelines/{}".format(destination_folder, filename), "w+")
    f.write(filecontent)
    f.close()

def get_compiled_template(stage, compile_obj):
    raw = Template(open('static/pipeline-j2/{}.j2'.format(stage)).read())
    return raw.render(compile_obj)

if __name__ == "__main__":
    action = globals()[sys.argv[1]]
    product = sys.argv[2]
    env = sys.argv[3]
    vsm = sys.argv[4]
    new_branch = "bot_earth"
    if len(sys.argv) > 5:
        new_branch = sys.argv[5]
    os.makedirs(id)
    os.makedirs("{}/pipelines/".format(id))

    vsm_list = []
    if vsm == 'All':
        for vsm_key in config.vsm_details.keys():
            vsm_list.append(vsm_key)
    else:
        vsm_list.append(vsm)

    env_list = []
    if env == 'All':
        for env_key in config.env_details.keys():
            env_list.append(env_key)
    else:
        for env_key in env.split(','):
            env_list.append(env_key)

    print('Validating product\'s config')
    validate(product)
    
    print ('------------------------------------')
    print('Calling', action, 'with parameters', product, vsm, 'and' ,env )    
    for vsm_paac in vsm_list: 
        for env_name in env_list:
            # create as per action
            action(product,env_name,vsm_paac)

    repo = config.product_details[product]['git_repo_url']
    print ('------------------------------------')
    print('Pushing changes to', repo, new_branch)
    commit_to_git(product,repo,new_branch)