# -*- coding: utf-8 -*-
"""
Created on Fri Nov 27 19:05:59 2020

@author: yogeesh.hegde
"""
import sys
import os
from pprint import pprint
import config
for product in config.product_details:
    cmd=""
    cmd="py commands.py create_all_pipelines " +product+" All All"
    pprint(cmd)
    #os.system(cmd)

