from jinja2 import Template
import json
import config
import nomad_config
import sys
import uuid 
import os
import requests
from git.repo.base import Repo
from shutil import copy2
from pprint import pprint



id = str(uuid.uuid4())
print("Creating ID: " + id)
#not_products=["iPerform","iContract"]
global base_dir
base_dir = os.getcwd()

def create_all_hcl(product,env):
    print('Executing create_all_hcl for',product, env)
    #for product not in not_products: 
    if env == "All":
        for env in config.env_details.keys():
            create_downtime_hcl(product,env)
            create_ert_hcl(product,env)
    else:
        create_downtime_hcl(product,env)
        create_ert_hcl(product,env)

def create_downtime_hcl(product,env):
    print('Executing create_downtime_hcl for',product, env)
    
    product_nomad_details = nomad_config.product_details[product]
    nomad_regions = config.env_details[env]['nomad_regions']
    groups = product_nomad_details['groups']
    node_count = groups[0]['node_count']
    if node_count == "infra":
        n_count = fetch_node_count_from_infra(product,env)
    elif node_count == "infra_group":
        print(node_count)
        n_count = fetch_node_count_from_infra_group(product,env)
    else:
        n_count = node_count
    compile_obj = {"product" :  product, "env" : env, "nomad_regions" : nomad_regions, "groups" : groups, "hcl_type" : "downtime","node_count" : n_count}
    final = get_compiled_template("nomad_master", compile_obj)

    name = "{}_deploy_downtime.hcl".format(product.lower())
    save_file(name, id, final, env)
    return final, name

def create_ert_hcl(product,env):
    print('Executing create_ert_hcl for',product, env) 

    product_nomad_details = nomad_config.product_details[product]
    nomad_regions = config.env_details[env]['nomad_regions']
    groups = product_nomad_details['groups']
    node_count = groups[0]['node_count']
    if node_count == "infra":
        n_count = fetch_node_count_from_infra(product,env)
    #elif node_count == "infra_group":
    #    n_count = fetch_node_count_from_infra_group(product,env)
    else:
        n_count = node_count
    compile_obj = {"product" :  product, "env" : env, "nomad_regions" : nomad_regions, "groups" : groups, "hcl_type" : "ert","node_count" : n_count}
    final = get_compiled_template("nomad_master", compile_obj)

    name = "{}_patch_rolling.hcl".format(product.lower())
    save_file(name, id, final, env)
    return final, name    

def commit_to_git(product, repo, env):
    #print('Executing commit_to_git for',env)
    #change dir to dir of the script everytime this functions runs in loop to reset the working dir
    os.chdir(base_dir)
    folder_name = repo.split("/")[-1].split(".")[0]
    Repo.clone_from(repo, "{}/nomad/{}/{}".format(id,env,folder_name), branch=env)
    os.chdir("{}/nomad/{}/{}".format(id,env,folder_name))
    names = os.listdir("../hcl_files")
    os.system("git checkout -b bot_{}_{}".format(env,product))
    os.system("git pull origin bot_{}_{}".format(env,product))
    for name in names:
        srcname = os.path.join("../hcl_files".format(id), name)
        dstname = os.path.join("live/{}".format(product), name)
        copy2(srcname, dstname)  
    os.system("git add *")
    os.system('git commit -m "bot checking in"')
    os.system("git push origin bot_{}_{}".format(env,product))
    raise_merge_request(folder_name,env)

def raise_merge_request(folder_name,env):
    #print('Executing raise_merge_request for ',env)
    repo_name = folder_name
    gitlabAccessToken = 'r6YZQtTerPb37tgdUL13'
    header = {'PRIVATE-TOKEN' : gitlabAccessToken}
    project_url = 'http://gitlab.zycus.net/api/v4/projects/root%2F{}'.format(repo_name)
    project_details = requests.get(project_url, headers=header)
    project_details_json = project_details.json()
    project_id = project_details_json['id']
    MR_api_url = 'http://gitlab.zycus.net/api/v4/projects/{}/merge_requests'.format(project_id)

    sourceBranch = 'bot_{}_{}'.format(env,product)
    targetBranch = env
    title = 'MR from bot_{}_{} to {}'.format(env,product,env)
    description = 'description'

    header = {'PRIVATE-TOKEN' : gitlabAccessToken}
    params = {
            'id'            : id,    
            'title'         : title, 
            'source_branch' : sourceBranch, 
            'target_branch' : targetBranch
            }

    reply = requests.post(MR_api_url, data=params, headers=header)
    status = json.loads(reply.text)
    MR_URL = status['web_url']
    print ('MR raised at: ', MR_URL)

def save_file(filename, destination_folder, filecontent, env):
    os.makedirs("{}/nomad/{}/hcl_files".format(destination_folder,env),exist_ok = True)
    f = open("{}/nomad/{}/hcl_files/{}".format(destination_folder,env,filename), "w+")
    f.write(filecontent)
    f.close()

def get_compiled_template(stage, compile_obj):
    raw = Template(open('static/requirements-j2/{}.j2'.format(stage)).read())
    return raw.render(compile_obj)
    
def fetch_node_count_from_infra(product,env):
    infra = requests.get("http://gitlab.zycus.net/root/cicd-infra-json/raw/master/"+product+"/infra.json")
    infra_json = infra.json()
    print("Following is the valus for node_count")
    return len(infra_json[env]["node_count"])
    #pprint(node_count)
    #return node_count
    #exit()

def fetch_node_count_from_infra_group(product,env):
    product_nomad_details = nomad_config.product_details[product]
    nomad_regions = config.env_details[env]['nomad_regions']
    groups = product_nomad_details['groups']
    node_count = groups[0]['node_count']
    infra = requests.get("http://gitlab.zycus.net/root/cicd-infra-json/raw/master/"+product+"/infra.json")
    infra_json = infra.json()
    print("Following is the valus for node_count")
    product_len=len(product)
    print(product_len)
    product_split=product.split("-")
#product_len=len(product_split)
#print(len(product_split))
    sliceed=(groups[product_len+1:])
    print(sliceed)
    nodes=infra_json[env]["node_count"]
    print(nodes)
    for x in nodes:
       print(x)
       if x == sliceed:
        node_count = nodes[x]
        print(node_count)
        return node_count

if __name__ == "__main__":
    action = globals()[sys.argv[1]]
    product = sys.argv[2]
    env = sys.argv[3]

    os.makedirs(id)
    os.makedirs("{}/nomad/".format(id))

    env_list = []
    if env == 'All':
        for env_key in config.env_details.keys():
            env_list.append(env_key)
    else:
        for env_key in env.split(','):
            env_list.append(env_key)

    # create as per action
    for env_name in env_list:
        # create as per action
        print('Calling', action, 'with parameters', product, env_name)
        action(product,env_name)

    repo = "http://gitlab.zycus.net/root/nomad-code.git"
    print('Pushing changes to ', repo)
    if env == "All":
        for env in config.env_details.keys():
            commit_to_git(product,repo,env)
    else:
        for env_name in env_list:
            commit_to_git(product,repo,env_name)