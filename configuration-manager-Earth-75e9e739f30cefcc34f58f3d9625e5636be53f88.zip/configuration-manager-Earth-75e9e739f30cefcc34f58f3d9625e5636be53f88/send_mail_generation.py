import sys
import requests
from pprint import pprint
import os
import smtplib
mailserver = '192.168.4.84'

def send_mail(product,MR_URL,commiter):
    sender = 'gocd_pipeline_generation@zycus.com'
    receivers = []
    receivers = [commiter,'aakash.sinha@zycus.com']
    part1 ="""Subject: Pipeline Merge Request for """+product+"\n"
    message="Changes is requested in  pipeline of "+product+" "+"\n"
    message=message+"\n"+"This is requested by  "+commiter+"\n"
    message=message+"Refer the below url for MR "+"\n"
    message=message+"\n"+MR_URL+"\n"
    messages = part1 + message
    smtpObj = smtplib.SMTP(mailserver)
    smtpObj.sendmail(sender,receivers,messages)    
