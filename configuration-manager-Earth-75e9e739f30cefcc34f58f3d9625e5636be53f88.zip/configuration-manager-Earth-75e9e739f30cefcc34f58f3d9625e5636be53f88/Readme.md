## Pre-requisites

- Need to have Python (preferably 3.9.2) installed on local machine.
- Ensure below python modules are installed :
    - pip install pygit
    - pip install gitpython
    - pip install requests
    - pip install jinja2
    - pip install repo
    - pip install ruamel.yaml

## How to create pipelines

- Make sure details for product are present and are correct in config.py (Refer java-maven-app as a sample)
- Once added, execute below command as required

`python commands.py <action> <product> <env> <vsm>`

where action can be 

- create_all_pipelines
- create_build_pipelines
- create_package_pipelines
- create_deploy_downtime_pipelines
- create_deploy_ert_pipelines

product name must be as mentioned in config.py

env can be either All or specific eg. QC

env: Standard Environment name as mentioned in http://gitlab.zycus.net/root/gocd-scripts/blob/master/environments.json

vsm can be either All or specific eg Release or Patch

## How to create Nomad .hcl files

- Make sure details for product are present and are correct in nomad_config.py (Refer java-maven-app as a sample)
- Once added, execute below command as required

`python nomad_commands.py <action> <product> <env> <vsm>`

where action can be 

- create_all_hcl
- create_downtime_hcl
- create_ert_hcl

product name must be as mentioned in config.py

env can be either All or specific eg. QC

env: Standard Environment name as mentioned in http://gitlab.zycus.net/root/gocd-scripts/blob/master/environments.json

## How to create ERTDowntime pipelines

`python commands.py "create_deploy_ertdowntime_pipelines" <product> <env> <vsm>`