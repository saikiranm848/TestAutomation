product_details = {
    "java-maven-app" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "5m",
                "healthy_deadline" : "15m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/java-maven-app/apache-tomcat-8.5.6/bin/catalina.sh run 2>&1  | tee -a /U01/java-maven-app/apache-tomcat-8.5.6/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8080",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/java-maven-app/health",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
						]
                    }
                ]
            }
        ]
    },
    "eProc" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/eProc/service_node/application/software/apache-tomcat-9.0.8/bin/catalina.sh run 2>&1 | tee -a /U01/eProc/service_node/application/software/apache-tomcat-9.0.8/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8181",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/eproc/rest/eproc/health-check/checkService",
                                "interval" : "5s",
                                "timeout" : "5s"
                            }
						]	
					},
					{
                        "task_type" : "php",
                        "startup_command": "/usr/local/php-7.2.3/sbin/php-fpm -F -R --fpm-config /usr/local/php-7.2.3/etc/php-fpm.conf --pid /usr/local/php-7.2.3/var/run/php-fpm.pid"
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "1s",
                                "timeout" : "5s"
                            }
						]	
					}
                ]
            },			
            {
                "node_type" : "integration_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/eProc/integration_node/application/software/apache-tomcat-9.0.8/bin/catalina.sh run 2>&1 | tee -a /U01/eProc/integration_node/application/software/apache-tomcat-9.0.8/logs/catalina.out",
                        "port_name": "integration_tomcat",
                        "port": "8080",
               
                    }
                ]
            }
        ]
    },
	"DewDrops-Common" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/DewDrops-Common/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/DewDrops-Common/startup.log",
                        "port_name": "service_bff",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            },
                            {
                                "name" : "dependency_check",
                                "type" : "http",
                                "path" : "/u/dd/health/deepCheck",
                                "interval" : "180s",
                                "timeout" : "60s"
                            }
                        ]
                    },
                    {
                        "task_type" : "nginx",
                        "startup_command": "",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
                        ]
                    }
                ]
            }
		]
	},
	"DewDrops-Common-Services" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "service",
                        "startup_command": "/U01/DewDrops-Common-Services/bin/start.sh  2>&1 | tee -a /U01/Logs/DewDrops-Common-Services/startup.log",
                        "port_name": "service_port",
                        "port": "38080",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "dd-common-services/soa-services/restapi/header/healthCheck",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]
					}
                ]
            }
        ]
    },
	"DewDrops-CNS" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/DewDrops-CNS/bin/start.sh gocd-start 2>&1",
                        "port_name": "service_bff",
                        "port": "3300",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            },
							{
                                "name" : "dependency_check",
                                "type" : "http",
                                "path" : "/u/dd/health/deepCheck",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]
					}
                ]
            }
        ]
    },
	"DewDrops-CNS-Services" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "1m",
                "healthy_deadline" : "12m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "cd /U01/DewDrops-CNS-Services/bin; ./start.sh  2>&1",
                        "port_name": "service_port",
                        "port": "38082",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/dd-cns-services/soa-services/restapi/healthCheck.html",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]
							
					}
                ]
            }
        ]
    },
    "DewDrops-iRequest" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/DewDrops-iRequest/bin/start.sh gocd-start  2>&1 | tee -a /U01/Logs/DewDrops-iRequest/startup.log",
                        "port_name": "service_port",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            },
                            {
                                "name" : "dependency_check",
                                "type" : "http",
                                "path" : "/u/dd/health/deepcheck",
                                "interval" : "180s",
                                "timeout" : "60s"
                            }
                        ]
                    },
                        
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.con",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]
					}
                ]
            }
        ]
    },
	"DewDrops-LMT" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/DewDrops-LMT/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/DewDrops-LMT/startup.log",
                        "port_name": "service_bff",
                        "port": "3100",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            },
							{
                                "name" : "dependency_check",
                                "type" : "http",
                                "path" : "/u/dd/health/deepCheck",
                                "interval" : "180s",
                                "timeout" : "60s"
                            }
						]
					}
                ]
            }
        ]
    },
	"DewDrops-LMT-Services" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/DewDrops-LMT/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/DewDrops-LMT/startup.log",
                        "port_name": "service_bff",
                        "port": "3100",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            },
							{
                                "name" : "dependency_check",
                                "type" : "http",
                                "path" : "/u/dd/health/deepCheck",
                                "interval" : "180s",
                                "timeout" : "60s"
                            }
						]	
					}
                ]
            }
        ]
    },
	"DewDrops-CRMS" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/DewDrops-CRMS/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/DewDrops-CRMS/startup.log",
                        "port_name": "service_bff",
                        "port": "3100",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            },
							{
                                "name" : "dependency_check",
                                "type" : "http",
                                "path" : "/u/dd/health/deepCheck",
                                "interval" : "180s",
                                "timeout" : "60s"
                            }
						]
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.con",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/crms",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]
					}
                ]
            }
        ]
    },
	"DewDrops-iAnalyze" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/DewDrops-iAnalyze/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/DewDrops-iAnalyze/startup.log",
                        "port_name": "service_bff",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            },
							{
                                "name" : "dependency_check",
                                "type" : "http",
                                "path" : "/u/dd/health/deepCheck",
                                "interval" : "180s",
                                "timeout" : "60s"
                            }
						]	
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]
					}
                ]
            }
        ]
    },
	"DewDrops-iSave" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "60s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/DewDrops-iSave/bin/start.sh gocd-start  2>&1 | tee -a /U01/Logs/DewDrops-iSave/startup.log",
                        "port_name": "service_bff",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            },
							{
                                "name" : "dependency_check",
                                "type" : "http",
                                "path" : "/u/dd/health/deepCheck",
                                "interval" : "180s",
                                "timeout" : "60s"
                            }
						]
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/isave",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]
					}
                ]
            }
        ]
    },
    "DewDrops-iManage" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "60s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/DewDrops-iManage/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/DewDrops-iManage/startup.log",
                        "port_name": "service_bff",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "10s"
                            },
							{
                                "name" : "dependency_check",
                                "type" : "http",
                                "path" : "/u/dd/health/deepCheck",
                                "interval" : "180s",
                                "timeout" : "10s"
                            }
						]
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/imanage",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]
					}
                ]
            }
        ]
    },
	"DewDrops-iSource" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/DewDrops-iSource/bin/start.sh gocd-start  2>&1 | tee -a /U01/Logs/DewDrops-iSource/startup.log",
                        "port_name": "service_bff",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            },
							{
                                "name" : "dependency_check",
                                "type" : "http",
                                "path" : "/u/dd/health/deepCheck",
                                "interval" : "180s",
                                "timeout" : "60s"
                            }
						]	
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/isave",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]	
					}
                ]
            }
        ]
    },
	"DewDrops-iContract" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "1m",
                "healthy_deadline" : "10m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/DewDrops-iContract/bin/start.sh gocd-start  2>&1 | tee -a /U01/Logs/DewDrops-iContract/startup.log",
                        "port_name": "service_bff",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            },
							{
                                "name" : "dependency_check",
                                "type" : "http",
                                "path" : "/u/dd/health/deepCheck",
                                "interval" : "180s",
                                "timeout" : "60s"
                            }
						]	
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/icontract",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]	
					}
                ]
            }
        ]
    },
	"iContract-Standalone-Services" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/iContract_Standalone_Services/bin/start.sh  2>&1 | tee -a /U01/Logs/iContract_Standalone_Services/startup.log",
                        "port_name": "service_port",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/actuator/health",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]	
					}
					
                ]
            }
        ]
    },
	"DewDrops-eProc" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/DewDrops-eProc/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/DewDrops-eProc/startup.log",
                        "port_name": "service_bff",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            },
							{
                                "name" : "dependency_check",
                                "type" : "http",
                                "path" : "/u/dd/health/deepCheck",
                                "interval" : "180s",
                                "timeout" : "60s"
                            }
						]	
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]	
					}
                ]
            }
        ]
    },
	"DewDrops-eInvoice" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/DewDrops-eInvoice/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/DewDrops-eInvoice/startup.log",
                        "port_name": "service_bff",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            },
							{
                                "name" : "dependency_check",
                                "type" : "http",
                                "path" : "/u/dd/health/deepCheck",
                                "interval" : "180s",
                                "timeout" : "60s"
                            }
						]	
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]	
					}
                ]
            }
        ]
    },
	"DewDrops-iPerform" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/DewDrops-iPerform/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/DewDrops-iPerform/startup.log",
                        "port_name": "service_bff",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            },
							{
                                "name" : "dependency_check",
                                "type" : "http",
                                "path" : "/u/dd/health/deepCheck",
                                "interval" : "180s",
                                "timeout" : "60s"
                            }
						]	
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]	
					}
                ]
            }
        ]
    },
	"DewDrops-itemMaster" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/DewDrops-itemMaster/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/DewDrops-itemMaster/startup.log",
                        "port_name": "service_bff",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            },
							{
                                "name" : "dependency_check",
                                "type" : "http",
                                "path" : "/u/dd/health/deepCheck",
                                "interval" : "180s",
                                "timeout" : "60s"
                            }
						]	
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]	
					}
                ]
            }
        ]
    },
	"DewDrops-iMaster" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/DewDrops-iMaster/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/DewDrops-iMaster/startup.log",
                        "port_name": "service_bff",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            },
							{
                                "name" : "dependency_check",
                                "type" : "http",
                                "path" : "/u/dd/health/deepCheck",
                                "interval" : "180s",
                                "timeout" : "60s"
                            }
						]	
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]	
					}
                ]
            }
        ]
    },
	"DewDrops-canvas" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/DewDrops-canvas/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/DewDrops-canvas/startup.log",
                        "port_name": "service_bff",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            },
							{
                                "name" : "dependency_check",
                                "type" : "http",
                                "path" : "/u/dd/health/deepCheck",
                                "interval" : "180s",
                                "timeout" : "60s"
                            }
						]	
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]	
					}
                ]
            }
        ]
    },
	"DewDrops-canvas" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/DewDrops-canvas/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/DewDrops-canvas/startup.log",
                        "port_name": "service_bff",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]	
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]	
					}
                ]
            }
        ]
    },
	"DewDrops-iSupplier" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/DewDrops-iSupplier/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/DewDrops-iSupplier/startup.log",
                        "port_name": "service_bff",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            },
							{
                                "name" : "dependency_check",
                                "type" : "http",
                                "path" : "/u/dd/health/deepCheck",
                                "interval" : "180s",
                                "timeout" : "60s"
                            }
						]	
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]	
					}
                ]
            }
        ]
    },
	"DewDrops-ZSP" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/DewDrops-ZSP/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/DewDrops-ZSP/startup.log",
                        "port_name": "service_bff",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            },
							{
                                "name" : "dependency_check",
                                "type" : "http",
                                "path" : "/u/dd/health/deepCheck",
                                "interval" : "180s",
                                "timeout" : "60s"
                            }
						]	
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]	
					}
                ]
            }
        ]
    },
	"eInvoice" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "15m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/eInvoice/service_node/software/apache-tomcat-8.5.6/bin/catalina.sh run 2>&1 | tee -a /U01/eInvoice/service_node/software/apache-tomcat-8.5.6/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8181",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "5s",
                                "timeout" : "5s"
                            }
						]	
					},
					{
                        "task_type" : "php",
                        "startup_command": "/usr/local/php-5.5.16/sbin/php-fpm -F -R --fpm-config /usr/local/php-5.5.16/etc/php-fpm.conf --pid /usr/local/php-5.5.16/var/run/php-fpm.pid",
                        "port_name": "service_nginx",
                        
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "1s",
                                "timeout" : "5s"
                            }
						]	
					}
                ]
            }
        ]
    },
    "iRequest" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/iRequest/application/software/apache-tomcat-8.0.15/bin/catalina.sh run 2>&1 | tee -a /U01/iRequest/application/software/apache-tomcat-8.0.15/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8080",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "irequest/rest/irequest/health-check/checkService",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]	
					},
					{
                        "task_type" : "php",
                        "startup_command": "/usr/local/php-5.5.16/sbin/php-fpm -F -R --fpm-config /usr/local/php-5.5.16/etc/php-fpm.conf --pid /usr/local/php-5.5.16/var/run/php-fpm.pid",
                        "port_name": "service_nginx",
            
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/irequest/scripts/hello.php",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]	
					}
                ]
            }
        ]
    },
	"iRequestReporting" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/iRequest/application/software/apache-tomcat-7.0.22/bin/catalina.sh run 2>&1 | tee -a /U01/iRequest/application/software/apache-tomcat-7.0.22/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8080",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]	
					}
                ]
            }
        ]
    },
	"cwf" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "21m",
                "healthy_deadline" : "25m",
                "progress_deadline" : "30m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/cwf/service_node/application/software/apache-tomcat-9.0.8/bin/catalina.sh run 2>&1 | tee -a /U01/cwf/service_node/application/software/apache-tomcat-9.0.8/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8080",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/cwf/endpoint/healthCheck/checkService",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
                        ]
					},
					{
					    "task_type" : "php",
                        "startup_command": "/usr/local/php-5.5.16/sbin/php-fpm -F -R --fpm-config /usr/local/php-5.5.16/etc/php-fpm.conf --pid /usr/local/php-5.5.16/var/run/php-fpm.pid",	
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "1s",
                                "timeout" : "5s"
                            }
						]	
					}
                ]
            }
        ]
    },
	"FieldLibrary" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "1m",
                "healthy_deadline" : "12m",
                "progress_deadline" : "10m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/FieldLibrary/service_node/software/start.sh run 2>&1 | tee -a /U01/Logs/FieldLibrary/catalina_14380.out",
                        "port_name": "service_tomcat",
                        "port": "14380",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/iLibrary/ws/rest/actuator/health",
                                "interval" : "20s",
                                "timeout" : "30s"
                            },
                        ]
                    },
					{
                        "task_type" : "php",
                        "startup_command": "/usr/local/php-7.2.3/sbin/php-fpm -F -R --fpm-config /usr/local/php-7.2.3/etc/php-fpm.conf --pid /usr/local/php-7.2.3/var/run/php-fpm.pid"
                    }, 
                    {
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]	
					
							
					}
                ]
            }
        ]
    },
	"Flexiform" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Flexiform/service_node/software/start.sh run 2>&1 | tee -a /U01/Logs/Flexiform/catalina_14380.out",
                        "port_name": "service_tomcat",
                        "port": "8181",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/eform/health",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
                        ]                    
                    },
                    {
                        "task_type" : "php",
                        "startup_command": "/usr/local/php-7.2.3/sbin/php-fpm -F -R --fpm-config /usr/local/php-7.2.3/etc/php-fpm.conf --pid /usr/local/php-7.2.3/var/run/php-fpm.pid",	
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]	
					
							
					}
                ]
            }
        ]
    },
	"iMaster-Job" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/iMaster-Job/software/apache-tomcat-8.5.8/bin/catalina.sh run 2>&1 | tee -a /U01/iMaster-Job/software/apache-tomcat-8.5.8/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8181",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/imaster/rest/cmd/health-check/checkService",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
                        ]
			
					}
                ]
            }
        ]
    },
	"Flexiform" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Flexiform/service_node/software/start.sh run 2>&1 | tee -a /U01/Logs/Flexiform/catalina_14380.out",
                        "port_name": "service_tomcat",
                        "port": "8181",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/eform/health",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
                        ]
                    },
					{
                        "task_type" : "php",
                        "startup_command": "/usr/local/php-7.2.3/sbin/php-fpm -F -R --fpm-config /usr/local/php-7.2.3/etc/php-fpm.conf --pid /usr/local/php-7.2.3/var/run/php-fpm.pid",	
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]	
					
							
					}
                ]
            }
        ]
    },
	"iSource-eForum" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "cd /U01/iSource/eForum/; ./start.sh 2>&1 | tee -a /U01/Logs/eForum/gocd.logs",
                        "port_name": "service_tomcat",
                        "port": "8181",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "Eforum/health",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
                        ]
					}
		
                ]
            }
        ]
    },
	"itemMaster" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "5m",
                "healthy_deadline" : "10m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/itemmaster/bin/start.sh run 2>&1 | tee -a /U01/itemmaster/bin/nohup.out",
                        "port_name": "service_tomcat",
                        "port": "8181",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/rest/itemMaster/health-check/checkService",
                                "interval" : "10s",
                                "timeout" : "5s"
                            }
                        ]
					},
					{
                        "task_type" : "php",
                        "startup_command": "/usr/local/php-5.5.16/sbin/php-fpm -F -R --fpm-config /usr/local/php-5.5.16/etc/php-fpm.conf --pid /usr/local/php-5.5.16/var/run/php-fpm.pid",							
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "10s",
                                "timeout" : "5s"
                            }
						]	
					
							
					}
                ]
            }
        ]
    },
	"RuleManager" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/RuleManager/service_node/software/start.sh run 2>&1 | tee -a /U01/Logs/RuleManager/catalina_8181.out",
                        "port_name": "service_tomcat",
                        "port": "8181",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/rule-manager/health/checkService",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
                        ]   
					},
					{
                        "task_type" : "php",
                        "startup_command": "/usr/local/php-7.2.3/sbin/php-fpm -F -R --fpm-config /usr/local/php-7.2.3/etc/php-fpm.conf --pid /usr/local/php-7.2.3/var/run/php-fpm.pid",
							
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]			
					}
                ]
            }
        ]
    },
	"Workflow" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "",
                "healthy_deadline" : "",
                "progress_deadline" : "",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Workflow/service_node/software/apache-tomcat-7.0.22/bin/catalina.sh run 2>&1 | tee -a /U01/Workflow/service_node/software/apache-tomcat-7.0.22/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8080",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/workflow/rest/healthCheck/checkService",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"eProc-Job" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/eProc-Job/application/software/apache-tomcat-9.0.8/bin/catalina.sh run 2>&1 | tee -a /U01/eProc-Job/application/software/apache-tomcat-9.0.8/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8181",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/workflow/rest/healthCheck/checkService",
                                "interval" : "",
                                "timeout" : ""
                            }
                        ]
					}
                ]
            }
        ]
    },
	"eCatalog" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/eCatalog/service_node/software/apache-tomcat-8.5.8/bin/catalina.sh run 2>&1 | tee -a /U01/eCatalog/service_node/software/apache-tomcat-8.5.8/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8181",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/ecatalog/rest/ecatalog/health-check/checkService",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
                        ]
                    }, 
					{
                        "task_type" : "php",
                        "startup_command": "/usr/local/php-5.5.16/sbin/php-fpm -F -R --fpm-config /usr/local/php-5.5.16/etc/php-fpm.conf --pid /usr/local/php-5.5.16/var/run/php-fpm.pid",
                    		
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
						]	
					
							
					}
                ]
            }
        ]
    },
	"iMaster" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/iMaster/service_node/software/apache-tomcat-8.5.8/bin/catalina.sh run 2>&1 | tee -a /U01/iMaster/service_node/software/apache-tomcat-8.5.8/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8181",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/imaster/rest/cmd/health-check/checkService",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
						]

                    }
                
                ]
            },
			
            {
                "node_type" : "uiintegration_node",
                "node_count" : "2",
                "min_healthy_time" : "",
                "healthy_deadline" : "",
                "progress_deadline" : "",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/iMaster/uiintegration_node/software/apache-tomcat-8.5.8/bin/catalina.sh run 2>&1 | tee -a /U01/iMaster/uiintegration_node/software/apache-tomcat-8.5.8/logs/catalina.out",
                        "port_name": "uiintegration_tomcatt",
                        "port": "8181",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/imaster/rest/cmd/health-check/checkService",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
						]
                    },
					{
                        "task_type" : "php",
                        "startup_command": "/usr/local/php-5.5.16/sbin/php-fpm -F -R --fpm-config /usr/local/php-5.5.16/etc/php-fpm.conf --pid /usr/local/php-5.5.16/var/run/php-fpm.pid",		
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "uiintegration_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
						]	
					
							
					}
                ]
            }
        ]
    },
	"P2PContractUtilization" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3s",
                "healthy_deadline" : "9s",
                "progress_deadline" : "20s",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "service",
                        "startup_command": "/U01/P2PContractUtilization/service_node/bin/start.sh",
                        "port_name": "integration",
                        "port": "8093",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/contract-utilization/actuator/health",
                                "interval" : "10s",
                                "timeout" : "12s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"service-procurement" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "",
                "healthy_deadline" : "",
                "progress_deadline" : "",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "service",
                        "startup_command": "/U01/service-procurement/service_node/bin/start.sh",
                        "port_name": "integration",
                        "port": "8092",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/service-procurement/actuator/health",
                                "interval" : "10s",
                                "timeout" : "12s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"zsn" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "12m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/ZSN/service_node/application/software/apache-tomcat-8.5.8/bin/catalina.sh run 2>&1 | tee -a /U01/ZSN/service_node/application/software/apache-tomcat-8.5.8/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8181",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/zsn/rest/health-check/checkService",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
                    },   
					{
                        "task_type" : "php",
                        "startup_command": "/U01/ZSN/bin/php_start.sh 2>&1",	
					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
						]	
					}
							
				
                ]
            }
        ]
    },
	"iLogix-Solver" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "1",
                "min_healthy_time" : "1m",
                "healthy_deadline" : "12m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "service",
                        "startup_command": "cd /U01/iLogix/ilogix_solver; ./start.sh 2>&1",
                        "port_name": "service_port",
                        "port": "8103",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/solver/healthController/health",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"iLogix-Node" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "1",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "cd /U01/iLogix/ilogix_node; ./start.sh 2>&1 | tee -a /U01/Logs/ilogix_node/startup.log",
                        "port_name": "service_bff",
                        "port": "2000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/nodeapi/health",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"iLogix-Java" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "1",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "12m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "service",
                        "startup_command": "cd /U01/iLogix/ilogix_java; ./start.sh 2>&1 | tee -a /U01/Logs/ilogix_java/startup.log",
                        "port_name": "service_port",
                        "port": "8102",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/iLogix/health",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"ZDN-Query-Service" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "1",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "15m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "30s",
                "tasks" : [
                    {
                        "task_type" : "service",
                        "startup_command": "/U01/zdn-query-service/service_node/bin/start.sh run 2>&1",
                        "port_name": "service_port",
                        "port": "8080",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/zdn/actuator/health",
                                "interval" : "5s",
                                "timeout" : "5s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"crms-community-intelligence" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "1",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "service",
                        "startup_command": "/U01/crms-community-intelligence/service_node/bin/start.sh",
                        "port_name": "service_port",
                        "port": "8083",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/zci/service/health",
                                "interval" : "10s",
                                "timeout" : "12s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"DewDrops-ZDN" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/DewDrops-ZDN/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/DewDrops-ZDN/startup.log",
                        "port_name": "service_bff",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/zsn/rest/health-check/checkService",
                                "interval" : "20s",
                                "timeout" : "30s"
                            },
							{
                                "name" : "dependency_check",
                                "type" : "http",
                                "path" : "/u/dd/health/deepCheck",
                                "interval" : "180s",
                                "timeout" : "60s"
                            }
                        ]

					},
					{
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]	
					}
							
					
                ]
            }
        ]
    },
	"ZyMail" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "service",
                        "startup_command": "/U01/ZyMail/service_node/bin/start.sh",
                        "port_name": "integration",
                        "port": "8084",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/zymail/health-check/checkService",
                                "interval" : "10s",
                                "timeout" : "12s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"MRS" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "service",
                        "startup_command": "/U01/MRS/bin/start.sh",
                        "port_name": "integration",
                        "port": "28877",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/MRS/health/getMRSStatus",
                                "interval" : "10s",
                                "timeout" : "12s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"MAS" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/MAS/bin/start.sh",
                        "port_name": "integration",
                        "port": "28081",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/MAS/getMASStatus",
                                "interval" : "10s",
                                "timeout" : "12s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"OneView" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/OneView/service_node/application/software/apache-tomcat-8.5.15/bin/start.sh run 2>&1 | tee -a /U01/OneView/service_node/application/software/apache-tomcat-8.5.15/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8080",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/OneView/soa-services/restapi/springWebService/getOneViewStatus",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-Data-Extraction" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "cd /U01/Merlin-Data-Extraction/bin/; ./start.sh  2>&1 | tee -a /U01/Logs/Merlin-Data-Extraction/startup.log",
                        "port_name": "service_port",
                        "port": "9010",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin-data-extraction/service/healthcheck.html",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-AI-Invoice-PageHints" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "10m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "cd /U01/Merlin-AI-Invoice-PageHints/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-AI-Invoice-PageHints/startup.log",
                        "port_name": "service_port",
                        "port": "6001",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin/merlin-ai-invoice-pagehints/pagehints-gunicorn/healthCheck",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
    "Merlin-AI-Fraud-Requisition-Splitting" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "10m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-AI-Fraud-Requisition-Splitting/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-AI-Fraud-Requisition-Splitting/startup.log",
                        "port_name": "service_port",
                        "port": "6001",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin/merlinai-fraud-requisition-splitting/healthCheck",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
                        ]
					}
                ]
            }
        ]
    },
    "Merlin-AI-eProc-QM" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "10m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-AI-eProc-QM/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-AI-eProc-QM/startup.log",
                        "port_name": "service_port",
                        "port": "5005",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin/merlin_quote_match",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
    "Merlin-AI-Fraud-Email-Anomaly" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "10m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-AI-Fraud-Requisition-Splitting/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-AI-Fraud-Requisition-Splitting/startup.log",
                        "port_name": "service_port",
                        "port": "6001",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin/merlinai-fraud-requisition-splitting/healthCheck",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-Data-Extraction-Service" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "cd /U01/Merlin-Data-Extraction-Service/bin/; ./start.sh  2>&1 | tee -a /U01/Logs/Merlin-Data-Extraction-Service/startup.log",
                        "port_name": "service_port",
                        "port": "9010",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "merlin-data-extraction-backend-service/service/healthcheck.html",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-Invoice-BFF" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-Invoice-BFF/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/Merlin-Invoice-BFF/startup.log",
                        "port_name": "service_port",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-Invoice-Fraud-Detection" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "cd /U01/Merlin-Invoice-Fraud-Detection/bin/; ./start.sh  2>&1 | tee -a /U01/Logs/Merlin-Invoice-Fraud-Detection/startup.log",
                        "port_name": "service_port",
                        "port": "9013",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin-invoice-fraud-detection/service/healthcheck.html",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-Supplier-Risk" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "cd /U01/Merlin-Supplier-Risk/bin/; ./start.sh  2>&1 | tee -a /U01/Logs/Merlin-Supplier-Risk/startup.log",
                        "port_name": "service_port",
                        "port": "9076",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin-supplier-risk/service/healthcheck.html",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-AI-LibPostal" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "10m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-AI-LibPostal/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-AI-LibPostal/startup.log",
                        "port_name": "service_port",
                        "port": "6001",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin/models/libpostal/healthcheck",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-Supplier-Risk-Backend" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "cd /U01/Merlin-Supplier-Risk-Backend/bin/; ./start.sh  2>&1 | tee -a /U01/Logs/Merlin-Supplier-Risk-Backend/startup.log",
                        "port_name": "service_port",
                        "port": "9000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin-supplier-risk-backend/service/healthcheck.html",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-AI-Invoice-Snab" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "1m",
                "healthy_deadline" : "10m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-AI-Invoice-Snab/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-AI-Invoice-Snab/startup.log",
                        "port_name": "service_port",
                        "port": "6001",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlinai/invoice/snab/healthcheck",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-AI-Invoice-Predictions" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "10m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-AI-Invoice-Predictions/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-AI-Invoice-Predictions/startup.log",
                        "port_name": "service_port",
                        "port": "6001",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin/merlin-ai-invoice-predictions/predictions-gunicorn/healthCheck",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-AI-iContract-Discovery" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "1",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-AI-iContract-Discovery/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-AI-iContract-Discovery/startup.log",
                        "port_name": "service_port",
                        "port": "5550",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin/contract/healthChecker",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-Services-BFF" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-Services-BFF/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/Merlin-Services-BFF/startup.log",
                        "port_name": "service_port",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-eProc-BFF" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-eProc-BFF/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/Merlin-eProc-BFF/startup.log",
                        "port_name": "service_port",
                        "port": "9076",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"DewDrops-Merlin" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "1",
                "min_healthy_time" : "1m",
                "healthy_deadline" : "12m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/DewDrops-Merlin/bin/start.sh  2>&1 | tee -a /U01/Logs/DewDrops-Merlin/startup.log",
                        "port_name": "service_port",
                        "port": "9000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "dewdrops-merlin/service/healthcheck.html",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-eInvoice-Cost-Allocation" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "cd /U01/Merlin-eInvoice-Cost-Allocation/bin/; ./start.sh  2>&1 | tee -a /U01/Logs/Merlin-eInvoice-Cost-Allocation/startup.log",
                        "port_name": "service_port",
                        "port": "9011",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin-supplier-risk/service/healthcheck.html",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-ZDN" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "cd /U01/Merlin-ZDN/bin/; ./start.sh  2>&1 | tee -a /U01/Logs/Merlin-ZDN/startup.log",
                        "port_name": "service_port",
                        "port": "9000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin-zdn-ai-bot/service/healthcheck.html",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-AI-Eye" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-AI-Eye/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-AI-Eye/startup.log",
                        "port_name": "service_port",
                        "port": "5005",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin/Merlin-AI-Eye/healthCheck",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
    "Merlin-Supplier-Risk-Backend" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "cd /U01/Merlin-Supplier-Risk-Backend/bin/; ./start.sh  2>&1 | tee -a /U01/Logs/Merlin-Supplier-Risk-Backend/startup.log",
                        "port_name": "service_port",
                        "port": "9000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin-supplier-risk-backend/service/healthcheck.htmlk",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
    "Merlin-Supplier-BFF" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-Supplier-BFF/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/Merlin-Supplier-BFF/startup.log",
                        "port_name": "service_port",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
                        ]
					}
                ]
            }
        ]
    },
    "Merlin-Invoice-Email-Crawler" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "cd /U01/Merlin-Invoice-Email-Crawler/bin/; ./start.sh  2>&1 | tee -a /U01/Logs/Merlin-Invoice-Email-Crawler/startup.log",
                        "port_name": "service_port",
                        "port": "9089",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin-invoice-email-crawler/service/healthcheck.html",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
    "Merlin-Invoice-AP-Smart-Desk" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-Invoice-AP-Smart-Desk/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-Invoice-AP-Smart-Desk/startup.log",
                        "port_name": "service_port",
                        "port": "9089",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin-ap-smart-desk/service/healthcheck.html",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
                        ]
					}
                ]
            }
        ]
    },
    "Merlin-AI-Spacy" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-AI-Spacy/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-AI-Spacy/startup.log",
                        "port_name": "service_port",
                        "port": "9095",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/spacy/healthCheck",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
     "Merlin-AI-Smart-Desk" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "10m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-AI-Smart-Desk/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-AI-Smart-Desk/startup.log",
                        "port_name": "service_port",
                        "port": "6001",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin/apsmartdesk/healthchecK",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
         "Merlin-AI-Invoice-Snab" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "10m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-AI-Invoice-Snab/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-AI-Invoice-Snab/startup.log",
                        "port_name": "service_port",
                        "port": "6001",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlinai/invoice/snab/healthcheck",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
    "Merlin-Invoice-Suggested-Po" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "cd /U01/Merlin-Invoice-Suggested-Po/bin/; ./start.sh  2>&1 | tee -a /U01/Logs/Merlin-Invoice-Suggested-Po/startup.log",
                        "port_name": "service_port",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin-invoice-suggested-po/service/healthcheck.html",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-AI-Voice" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-AI-Voice/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-AI-Voice/startup.log",
                        "port_name": "service_port",
                        "port": "5005",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin/Merlin-AI-Voice/healthCheck",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-AI-ZDN" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-AI-ZDN/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-AI-ZDN/startup.log",
                        "port_name": "service_port",
                        "port": "5550",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "merlin/zdn/healthChecker",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-AI-Cost-Allocation" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-AI-Cost-Allocation/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-AI-Cost-Allocation/startup.log",
                        "port_name": "service_port",
                        "port": "5002",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin/costAllocation/healthCheck",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-eProc-Autonomous-Quick-Source" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "cd /U01/Merlin-eProc-Autonomous-Quick-Source/bin/; ./start.sh  2>&1 | tee -a /U01/Logs/Merlin-eProc-Autonomous-Quick-Source/startup.log",
                        "port_name": "service_port",
                        "port": "9010",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin-autonomous-quick-source/services/healthcheck.html",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-Invoice-Suggested-Po" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "cd /U01/Merlin-Invoice-Suggested-Po/bin/; ./start.sh  2>&1 | tee -a /U01/Logs/Merlin-Invoice-Suggested-Po/startup.log",
                        "port_name": "service_port",
                        "port": "9080",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin-invoice-suggested-po/service/healthcheck.html",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-AI-eProc-BA" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-AI-eProc-BA/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-AI-eProc-BA/startup.log",
                        "port_name": "service_port",
                        "port": "5005",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin/merlin_buyer_assignment",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            },
			{
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "5005",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-AI-eProc-BA/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-AI-eProc-BA/startup.log",
                        "port_name": "service_port",
                        "port": "5005",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin/merlin_buyer_assignment",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
        ]
    },
	"Merlin-AI-eProc-SD" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "5005",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-AI-eProc-SD/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-AI-eProc-SD/startup.log",
                        "port_name": "service_port",
                        "port": "5002",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin/eproc/supplierrecommendation/health",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
			
        ]
    },
	"Merlin-AI-Spend-PayTerm" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-AI-Spend-PayTerm/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-AI-Spend-PayTerm/startup.log",
                        "port_name": "service_port",
                        "port": "5500",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/v1.0/payment_term/healthcheck",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
			
        ]
    },
	"Merlin-iAnalyze-PaymentTerm" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "cd /U01/Merlin-iAnalyze-PaymentTerm/bin/; ./start.sh  2>&1 | tee -a /U01/Logs/Merlin-iAnalyze-PaymentTerm/startup.log",
                        "port_name": "service_port",
                        "port": "9091",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin-paymenttermbot/services/zycus/admin/actuator/health",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
			
        ]
    },
	"Merlin-AI-Spend-CategoryNormalization" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-AI-Spend-CategoryNormalization/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-AI-Spend-CategoryNormalization/startup.log",
                        "port_name": "service_port",
                        "port": "9080",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/v1.0/normalize/healthcheck",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
			
        ]
    },
	"Merlin-iContract-Insta-Review" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "cd /U01/Merlin-iContract-Insta-Review/bin/; ./start.sh  2>&1 | tee -a /U01/Logs/Merlin-iContract-Insta-Review/startup.log",
                        "port_name": "service_port",
                        "port": "9000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin-icontract-insta-review/service/healthcheck.html",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
			
        ]
    },
	"Merlin-iContract-Metadata" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "cd /U01/Merlin-iContract-Metadata/bin/; ./start.sh  2>&1 | tee -a /U01/Logs/Merlin-iContract-Metadata/startup.log",
                        "port_name": "service_port",
                        "port": "9000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin-icontract-metadata/service/healthcheck.html",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
			
        ]
    },
	"Merlin-Services-BFF" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-Services-BFF/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/Merlin-Services-BFF/startup.log",
                        "port_name": "service_port",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
			
        ]
    },
	"Merlin-iAnalyze-BFF" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-iAnalyze-BFF/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/Merlin-iAnalyze-BFF/startup.log",
                        "port_name": "service_port",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
			
        ]
    },
	"Merlin-Services" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "cd /U01/Merlin-Services/bin/; ./start.sh  2>&1 | tee -a /U01/Logs/Merlin-Services/startup.log",
                        "port_name": "service_port",
                        "port": "9091",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin-services/service/healthcheck.html",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
			
        ]
    },
	"MerlinUI" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "1",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "nginx",
                        "startup_command": "/etc/nginx/nginx.conf",
                        "port_name": "service_nginx",
                        "port": "80",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/status",
                                "interval" : "20s",
                                "timeout" : "80s"
                            }
                        ]
					}
                ]
            }
			
        ]
    },
	"Merlin-Poller" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "cd /U01/Merlin-Poller/bin/; ./start.sh  2>&1 | tee -a /U01/Logs/Merlin-Poller/startup.log",
                        "port_name": "service_port",
                        "port": "9000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/poll/health",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
			
        ]
    },
	"Merlin-iContract-BFF" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-iContract-BFF/bin/start.sh gocd-start 2>&1 | tee -a /U01/Logs/Merlin-iContract-BFF/startup.log",
                        "port_name": "service_port",
                        "port": "3000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/u/dd/health/check",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
			
        ]
    },
	"Merlin-AI-Fraud-Duplicate-Invoices" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "20m",
                "progress_deadline" : "25m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/Merlin-AI-Fraud-Duplicate-Invoices/bin/start.sh  2>&1 | tee -a /U01/Logs/Merlin-AI-Fraud-Duplicate-Invoices/startup.log",
                        "port_name": "service_port",
                        "port": "7000",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/merlin/merlinai-fraud-duplicate-invoices/healthCheck",
                                "interval" : "10s",
                                "timeout" : "15s"
                            }
                        ]
					}
                ]
            }
			
        ]
    },
    "TMS" : {
        "groups" : [
            {
                "node_type" : "BUYER_SSO",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/TMS/SSO/bin/catalina.sh run 2>&1 | tee -a /U01/TMS/SSO/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8180",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "sso/rest/v2/health",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
                        ]
			
					}
                ]
            },
            {
                "node_type" : "BUYER_DP",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/TMS/SSO/bin/catalina.sh run 2>&1 | tee -a /U01/TMS/SSO/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8180",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "sso/rest/v2/health",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
                        ]
			
					}
                ]
            },
            {
                "node_type" : "BUYER_CCS",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/TMS/CCS/bin/catalina.sh run 2>&1 | tee -a /U01/TMS/CCS/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8380",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "ccs/health",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
                        ]
			
					}
                ]
            },
            {
                "node_type" : "BUYER_APP",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/TMS/APPLICATION/bin/catalina.sh run 2>&1 | tee -a /U01/TMS/APPLICATION/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8080",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "tms/rest/health",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
                        ]
			
					}
                ]
            }
        ]
    },
    "TMS" : {
        "groups" : [
            {
                "node_type" : "BUYER_SSO",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/TMS/SSO/bin/catalina.sh run 2>&1 | tee -a /U01/TMS/SSO/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8180",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "sso/rest/v2/health",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
                        ]
			
					}
                ]
            },
            {
                "node_type" : "BUYER_DP",
                "node_count" : "1",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/TMS/SSO/bin/catalina.sh run 2>&1 | tee -a /U01/TMS/SSO/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8180",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "sso/rest/v2/health",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
                        ]
					}
                ]
            },
            {
                "node_type" : "BUYER_CCS",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/TMS/CCS/bin/catalina.sh run 2>&1 | tee -a /U01/TMS/CCS/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8380",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "ccs/health",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
                        ]
			
					}
                ]
            },
            {
                "node_type" : "BUYER_APP",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/TMS/APPLICATION/bin/catalina.sh run 2>&1 | tee -a /U01/TMS/APPLICATION/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8080",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "tms/rest/health",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
                        ]
					}
                ]
            }
        ]
    },
    "TMS-Buyer" : {
        "groups" : [
            {
                "node_type" : "BUYER_SSO",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/TMS/SSO/bin/catalina.sh run 2>&1 | tee -a /U01/TMS/SSO/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8180",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "sso/rest/v2/health",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
                        ]
			
					}
                ]
            },
            {
                "node_type" : "BUYER_DP",
                "node_count" : "1",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/TMS/SSO/bin/catalina.sh run 2>&1 | tee -a /U01/TMS/SSO/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8180",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "sso/rest/v2/health",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
                        ]
			
					}
                ]
            },  
            {
                "node_type" : "BUYER_APP",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/TMS/APPLICATION/bin/catalina.sh run 2>&1 | tee -a /U01/TMS/APPLICATION/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8080",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "tms/rest/health",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
                        ]
			
					}
                ]
            }
        ]
    },
    "TMS-Supplier" : {
        "groups" : [
            {
                "node_type" : "BUYER_SSO",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/TMS/SSO/bin/catalina.sh run 2>&1 | tee -a /U01/TMS/SSO/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8180",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "sso/rest/v2/health",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
                        ]
			
					}
                ]
            },  
            {
                "node_type" : "BUYER_APP",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/TMS/APPLICATION/bin/catalina.sh run 2>&1 | tee -a /U01/TMS/APPLICATION/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8080",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "tms/rest/health",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
                        ]
			
					}
                ]
            }
        ]
    },
    "TMSAudit" : {
        "groups" : [
            {
                "node_type" : "service-node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/TMSAuditService/bin/start.sh",
                        "port_name": "service_tomcat",
                        "port": "8081",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "actuator/health",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
                        ]
			
					}
                ]
            }
        ]
    },
    "TMSBulk" : {
        "groups" : [
            {
                "node_type" : "service-node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/TMSBulkService/bin/start.sh",
                        "port_name": "service_tomcat",
                        "port": "8080",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "actuator/health",
                                "interval" : "7s",
                                "timeout" : "5s"
                            }
                        ]
			
					}
                ]
            }
        ]
    },
     "iSource" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "infra",
                "min_healthy_time" : "5m",
                "healthy_deadline" : "10m",
                "progress_deadline" : "15m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "tomcat",
                        "startup_command": "/U01/iSource/contexts/iSource/apache-tomcat-8.5.5/bin/catalina.sh run 2>&1 | tee -a /U01/iSource/contexts/iSource/apache-tomcat-8.5.5/logs/catalina.out",
                        "port_name": "service_tomcat",
                        "port": "8380",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "iSource/health",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
                        ]
					}
                ]
            }
        ]
    },
    "gds-bulk" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/gds-bulk-service/service_node/bin/start.sh",
                        "port_name": "service_port",
                        "port": "8080",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/api/1/rest/feed-master/queue/Zycus_GDS_LOCAL/QCVMWARE/GDS-BULK/actuator/health",
                                "interval" : "10s",
                                "timeout" : "12s"
                            }
						]
							
					}
                ]
            }
        ]
    },
    "gds-snaplogic" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/gds-snaplogic/service_node/bin/start.sh",
                        "port_name": "service_port",
                        "port": "8080",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/api/1/rest/feed-master/queue/Zycus_GDS_LOCAL/QCVMWARE/GDS/actuator/health",
                                "interval" : "10s",
                                "timeout" : "12s"
                            }
						]
							
					}
                ]
            }
        ]
    },
    "sim-req-backup-service" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "9m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/sim-req-backup-service/service_node/bin/start.sh",
                        "port_name": "service_port",
                        "port": "8088",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/sim/actuator/health",
                                "interval" : "10s",
                                "timeout" : "12s"
                            }
						]
							
					}
                ]
            }
        ]
    },
    "IAF" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "2m",
                "healthy_deadline" : "5m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "180s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/IAF/service_node/bin/start.sh run 2>&1 | tee -a /U01/Logs/IAF/catalina_8881.out",
                        "port_name": "service_port",
                        "port": "8881",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/actuator/health",
                                "interval" : "20s",
                                "timeout" : "30s"
                            }
						]
							
					}
                ]
            }
        ]
    },
    "ZDN-Query-Service" : {
        "groups" : [
            {
                "node_type" : "service_node",
                "node_count" : "2",
                "min_healthy_time" : "3m",
                "healthy_deadline" : "15m",
                "progress_deadline" : "20m",
                "shutdown_delay" : "30s",
                "tasks" : [
                    {
                        "task_type" : "bff",
                        "startup_command": "/U01/zdn-query-service/service_node/bin/start.sh run 2>&1",
                        "port_name": "service_port",
                        "port": "8080",
                        "healthchecks" : [
                            {
                                "name" : "self_check",
                                "type" : "http",
                                "path" : "/zdn/actuator/health",
                                "interval" : "5s",
                                "timeout" : "5s"
                            }
						]
							
					}
                ]
            }
        ]
    }


}