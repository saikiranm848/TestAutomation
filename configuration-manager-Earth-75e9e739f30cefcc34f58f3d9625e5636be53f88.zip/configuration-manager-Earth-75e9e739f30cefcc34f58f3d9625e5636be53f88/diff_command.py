import json
import os


def get_product_name():
    for key in (config_product["product_details"]):
        product = key
    return product

def get_env_list(type,Pipeline_type):
    env_list = []
    for env,pair in config_product["product_details"][product][type][Pipeline_type].items():
        env_list.append(env)
    return env_list

def get_pipeline_vsm():  #Release Patch comon
    pipeline_vsm = []
    for key in config_product["product_details"][product]:
        pipeline_vsm.append(key)
    return pipeline_vsm

def get_pipeline_type(type):  # get deploy_downtime etc
    Pipeline_type = []
    for key in config_product["product_details"][product][type]:  
        Pipeline_type.append(key)
    return Pipeline_type


def create_dict():    # Creates a tree data structue with inputs all false
    pipeline_vsm = get_pipeline_vsm()
    for key in pipeline_vsm:  #Release Patch comon
        d = {}
        d[key] = {}
        Pipeline_type = get_pipeline_type(key)
        for value in Pipeline_type: # get deploy_downtime etc
            if value in Env_spec:
                env_list = get_env_list(key,value)
                d[key][value] = {}
                for env in env_list:
                    d[key][value][env] = False
            else:
                d[key][value] = False
        add_dict(d)


def create_file(data):
     f = open(product + "_pipelines.json", "w") 
     f.write(data)


def create_output():
    num = 0
    global output
    for key, value in tree_dict[product].items(): # #Release Patch comon
        for pipeines, Flag_pipe in value.items():    # get deploy_downtime etc
            if Flag_pipe == True:
                str_ap =  key + " " + pipeines
                num  = num + 1
                dummy_dict = {num : str_ap }
                output.update(dummy_dict)
            if isinstance(Flag_pipe, dict):
                list_env = []
                for  env, env_flag in Flag_pipe.items():
                    if env_flag: 
                        list_env.append(env)
                else:
                    if  list_env:
                        mix =  key + " " + pipeines + " "+ ','.join(map(str,list_env))
                        num  += 1
                        dummy ={ num :  mix}
                        output.update(dummy)         
            

def add_dict(data):
    global tree_dict
    tree_dict[product].update(data)

    
def check_diff():
    global tree_dict
    types = get_pipeline_vsm()  #Release Patch comon
    for type in types:
        Pipeline_types = get_pipeline_type(type)    # get deploy_downtime etc
        for Pipeline_type in Pipeline_types:
            New = config_product["product_details"][product][type][Pipeline_type]
            Old = old_config_product["product_details"][product][type][Pipeline_type]
            if not New == Old:
                if Pipeline_type in Env_spec:
                    env_list = get_env_list(type,Pipeline_type)
                    for env in env_list:
                        new_config = config_product["product_details"][product][type][Pipeline_type][env]
                        old_config = old_config_product["product_details"][product][type][Pipeline_type][env]
                        if not new_config == old_config:
                            tree_dict[product][type][Pipeline_type][env] = True
                else:
                    tree_dict[product][type][Pipeline_type] = True



if __name__ == "__main__":
    cur_path = os.getcwd()
    file_config = os.path.join(cur_path,"sample_pipeline_config.json")
    with open(file_config) as f:
        config_product = json.loads(f.read())
    file_config_old = os.path.join(cur_path,"old_product_config.json")
    with open(file_config_old) as fa:
        old_config_product = json.loads(fa.read())
    Env_spec = ["deploy_downtime" , "deploy_ert"]
    product = get_product_name()
    global tree_dict
    tree_dict = {}
    global output
    output = {}
    tree_dict[product] = {}
    create_dict()
    check_diff()
    print(tree_dict)
    create_output()
    jsonStr = json.dumps(output,indent=4, sort_keys=True)
    print(jsonStr)
    create_file(jsonStr)
